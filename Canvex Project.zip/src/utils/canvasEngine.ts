import { BoardObject } from './storage';

export interface RenderOptions {
  scale?: number;
  offsetX?: number;
  offsetY?: number;
  gridMode?: 'none' | 'dots' | 'lines';
  gridSize?: number;
  darkMode?: boolean;
}

export function getStrokePoints(points: number[]): number[] {
  if (points.length < 4) return points;
  return points;
}

export function smoothPath(points: number[]): string {
  if (points.length < 4) return '';
  let d = `M ${points[0]} ${points[1]}`;
  for (let i = 2; i < points.length - 2; i += 2) {
    const mx = (points[i] + points[i + 2]) / 2;
    const my = (points[i + 1] + points[i + 3]) / 2;
    d += ` Q ${points[i]} ${points[i + 1]} ${mx} ${my}`;
  }
  d += ` L ${points[points.length - 2]} ${points[points.length - 1]}`;
  return d;
}

export function drawGrid(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  gridMode: 'none' | 'dots' | 'lines',
  gridSize: number,
  offsetX: number,
  offsetY: number,
  zoom: number,
  darkMode: boolean
) {
  if (gridMode === 'none') return;

  const startX = -((offsetX % (gridSize * zoom)) + gridSize * zoom) % (gridSize * zoom);
  const startY = -((offsetY % (gridSize * zoom)) + gridSize * zoom) % (gridSize * zoom);
  const step = gridSize * zoom;

  ctx.save();

  if (gridMode === 'dots') {
    const color = darkMode ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.18)';
    ctx.fillStyle = color;
    for (let x = startX; x < width; x += step) {
      for (let y = startY; y < height; y += step) {
        ctx.beginPath();
        ctx.arc(x, y, Math.min(1.5, zoom * 1.2), 0, Math.PI * 2);
        ctx.fill();
      }
    }
  } else if (gridMode === 'lines') {
    const color = darkMode ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.07)';
    ctx.strokeStyle = color;
    ctx.lineWidth = 1;
    for (let x = startX; x < width; x += step) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = startY; y < height; y += step) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }
  }

  ctx.restore();
}

export function renderObject(
  ctx: CanvasRenderingContext2D,
  obj: BoardObject,
  selected: boolean = false
) {
  if (!obj.visible && obj.visible !== undefined) return;

  ctx.save();
  ctx.globalAlpha = obj.opacity ?? 1;

  const ox = obj.x;
  const oy = obj.y;
  const ow = obj.width ?? 100;
  const oh = obj.height ?? 60;

  // Apply rotation
  if (obj.rotation && obj.rotation !== 0) {
    const cx = ox + ow / 2;
    const cy = oy + oh / 2;
    ctx.translate(cx, cy);
    ctx.rotate((obj.rotation * Math.PI) / 180);
    ctx.translate(-cx, -cy);
  }

  switch (obj.type) {
    case 'stroke':
      renderStroke(ctx, obj);
      break;
    case 'shape':
      renderShape(ctx, obj);
      break;
    case 'text':
      renderText(ctx, obj);
      break;
    case 'sticky':
      renderStickyNote(ctx, obj);
      break;
    case 'arrow':
      renderArrow(ctx, obj);
      break;
    case 'image':
      // Images rendered separately
      break;
    default:
      break;
  }

  if (selected) {
    renderSelectionBox(ctx, obj);
  }

  ctx.restore();
}

function renderStroke(ctx: CanvasRenderingContext2D, obj: BoardObject) {
  const pts = obj.points;
  if (!pts || pts.length < 2) return;

  ctx.beginPath();
  ctx.strokeStyle = obj.color || '#1a1d23';
  ctx.lineWidth = obj.strokeWidth || 2;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  if (obj.dashArray && obj.dashArray.length > 0) {
    ctx.setLineDash(obj.dashArray);
  } else {
    ctx.setLineDash([]);
  }

  const tool = obj.tool || 'pen';

  if (tool === 'marker' || tool === 'highlighter') {
    ctx.globalCompositeOperation = 'multiply';
    ctx.lineWidth = (obj.strokeWidth || 8) * 2;
    ctx.globalAlpha = 0.4;
  } else if (tool === 'pencil') {
    ctx.lineWidth = obj.strokeWidth || 1.5;
  }

  if (pts.length === 2) {
    ctx.arc(pts[0], pts[1], (obj.strokeWidth || 2) / 2, 0, Math.PI * 2);
    ctx.fill();
  } else {
    ctx.moveTo(pts[0], pts[1]);
    for (let i = 2; i < pts.length - 2; i += 2) {
      const mx = (pts[i] + pts[i + 2]) / 2;
      const my = (pts[i + 1] + pts[i + 3]) / 2;
      ctx.quadraticCurveTo(pts[i], pts[i + 1], mx, my);
    }
    ctx.lineTo(pts[pts.length - 2], pts[pts.length - 1]);
    ctx.stroke();
  }

  if (tool === 'marker' || tool === 'highlighter') {
    ctx.globalCompositeOperation = 'source-over';
  }
  ctx.setLineDash([]);
}

function renderShape(ctx: CanvasRenderingContext2D, obj: BoardObject) {
  const x = obj.x, y = obj.y;
  const w = obj.width || 100, h = obj.height || 60;
  const shapeType = obj.shapeType || 'rect';

  ctx.strokeStyle = obj.color || '#1a1d23';
  ctx.lineWidth = obj.strokeWidth || 2;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  if (obj.dashArray && obj.dashArray.length > 0) {
    ctx.setLineDash(obj.dashArray);
  } else {
    ctx.setLineDash([]);
  }

  ctx.beginPath();

  switch (shapeType) {
    case 'rect':
      ctx.roundRect(x, y, w, h, 4);
      break;
    case 'ellipse':
      ctx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
      break;
    case 'triangle':
      ctx.moveTo(x + w / 2, y);
      ctx.lineTo(x + w, y + h);
      ctx.lineTo(x, y + h);
      ctx.closePath();
      break;
    case 'diamond':
      ctx.moveTo(x + w / 2, y);
      ctx.lineTo(x + w, y + h / 2);
      ctx.lineTo(x + w / 2, y + h);
      ctx.lineTo(x, y + h / 2);
      ctx.closePath();
      break;
    case 'hexagon': {
      const cx = x + w / 2, cy = y + h / 2;
      const rx = w / 2, ry = h / 2;
      for (let i = 0; i < 6; i++) {
        const angle = (Math.PI / 3) * i - Math.PI / 6;
        const px = cx + rx * Math.cos(angle);
        const py = cy + ry * Math.sin(angle);
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      break;
    }
    case 'star': {
      const cx = x + w / 2, cy = y + h / 2;
      const outer = Math.min(w, h) / 2;
      const inner = outer * 0.4;
      for (let i = 0; i < 10; i++) {
        const angle = (Math.PI / 5) * i - Math.PI / 2;
        const r = i % 2 === 0 ? outer : inner;
        const px = cx + r * Math.cos(angle);
        const py = cy + r * Math.sin(angle);
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      break;
    }
    case 'line':
      ctx.moveTo(x, y + h / 2);
      ctx.lineTo(x + w, y + h / 2);
      break;
    case 'arrow': {
      const headLen = Math.min(w * 0.15, 20);
      ctx.moveTo(x, y + h / 2);
      ctx.lineTo(x + w - headLen, y + h / 2);
      ctx.moveTo(x + w, y + h / 2);
      ctx.lineTo(x + w - headLen, y + h / 2 - headLen * 0.6);
      ctx.moveTo(x + w, y + h / 2);
      ctx.lineTo(x + w - headLen, y + h / 2 + headLen * 0.6);
      break;
    }
    default:
      ctx.roundRect(x, y, w, h, 4);
  }

  if (obj.filled && obj.fillColor && shapeType !== 'line' && shapeType !== 'arrow') {
    ctx.fillStyle = obj.fillColor;
    ctx.fill();
  }
  ctx.stroke();
  ctx.setLineDash([]);
}

function renderText(ctx: CanvasRenderingContext2D, obj: BoardObject) {
  const text = obj.text || '';
  if (!text) return;

  const fontSize = obj.fontSize || 16;
  const fontFamily = obj.fontFamily || 'Inter, sans-serif';
  const fontWeight = obj.fontWeight || 'normal';
  const fontStyle = obj.fontStyle || 'normal';

  ctx.font = `${fontStyle} ${fontWeight} ${fontSize}px ${fontFamily}`;
  ctx.fillStyle = obj.color || '#1a1d23';
  ctx.textAlign = (obj.textAlign as CanvasTextAlign) || 'left';
  ctx.textBaseline = 'top';

  const maxWidth = obj.width || 300;
  const lineHeight = fontSize * 1.4;
  const words = text.split('\n');
  let yOffset = obj.y;

  words.forEach(line => {
    const parts = line.split(' ');
    let currentLine = '';
    for (const word of parts) {
      const testLine = currentLine ? `${currentLine} ${word}` : word;
      const metrics = ctx.measureText(testLine);
      if (metrics.width > maxWidth && currentLine) {
        ctx.fillText(currentLine, obj.x, yOffset);
        currentLine = word;
        yOffset += lineHeight;
      } else {
        currentLine = testLine;
      }
    }
    ctx.fillText(currentLine, obj.x, yOffset);
    yOffset += lineHeight;
  });
}

function renderStickyNote(ctx: CanvasRenderingContext2D, obj: BoardObject) {
  const x = obj.x, y = obj.y;
  const w = obj.width || 160, h = obj.height || 120;
  const noteColor = obj.noteColor || '#fef3c7';

  // Shadow
  ctx.shadowColor = 'rgba(0,0,0,0.15)';
  ctx.shadowBlur = 12;
  ctx.shadowOffsetY = 4;

  // Background
  ctx.fillStyle = noteColor;
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, 6);
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.shadowOffsetY = 0;

  // Header bar
  const headerColor = shadeColor(noteColor, -15);
  ctx.fillStyle = headerColor;
  ctx.beginPath();
  ctx.roundRect(x, y, w, 28, [6, 6, 0, 0]);
  ctx.fill();

  // Dots on header
  ctx.fillStyle = shadeColor(noteColor, -30);
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.arc(x + w - 18 + i * 0, y + 14, 2.5, 0, Math.PI * 2);
    ctx.fill();
  }

  // Text
  if (obj.text) {
    const fontSize = obj.fontSize || 13;
    ctx.font = `${fontSize}px Inter, sans-serif`;
    ctx.fillStyle = '#374151';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    const padding = 10;
    const maxW = w - padding * 2;
    const lineH = fontSize * 1.5;
    const lines = obj.text.split('\n');
    let ty = y + 36;
    for (const line of lines) {
      if (ty > y + h - padding) break;
      const words = line.split(' ');
      let cur = '';
      for (const word of words) {
        const test = cur ? `${cur} ${word}` : word;
        if (ctx.measureText(test).width > maxW && cur) {
          ctx.fillText(cur, x + padding, ty);
          cur = word;
          ty += lineH;
        } else {
          cur = test;
        }
      }
      if (cur) ctx.fillText(cur, x + padding, ty);
      ty += lineH;
    }
  }
}

function shadeColor(color: string, percent: number): string {
  // Simple color darkening
  let r = parseInt(color.slice(1, 3), 16);
  let g = parseInt(color.slice(3, 5), 16);
  let b = parseInt(color.slice(5, 7), 16);
  r = Math.max(0, Math.min(255, r + percent));
  g = Math.max(0, Math.min(255, g + percent));
  b = Math.max(0, Math.min(255, b + percent));
  return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
}

function renderArrow(ctx: CanvasRenderingContext2D, obj: BoardObject) {
  const x1 = obj.x, y1 = obj.y;
  const x2 = obj.x2 ?? obj.x + 100, y2 = obj.y2 ?? obj.y;

  ctx.strokeStyle = obj.color || '#1a1d23';
  ctx.lineWidth = obj.strokeWidth || 2;
  ctx.lineCap = 'round';

  if (obj.dashArray && obj.dashArray.length > 0) {
    ctx.setLineDash(obj.dashArray);
  }

  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();

  // Arrowhead
  const angle = Math.atan2(y2 - y1, x2 - x1);
  const headLen = 14;

  if (obj.endArrow !== false) {
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - headLen * Math.cos(angle - Math.PI / 6), y2 - headLen * Math.sin(angle - Math.PI / 6));
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - headLen * Math.cos(angle + Math.PI / 6), y2 - headLen * Math.sin(angle + Math.PI / 6));
    ctx.stroke();
  }

  if (obj.startArrow) {
    const angle2 = Math.atan2(y1 - y2, x1 - x2);
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x1 - headLen * Math.cos(angle2 - Math.PI / 6), y1 - headLen * Math.sin(angle2 - Math.PI / 6));
    ctx.moveTo(x1, y1);
    ctx.lineTo(x1 - headLen * Math.cos(angle2 + Math.PI / 6), y1 - headLen * Math.sin(angle2 + Math.PI / 6));
    ctx.stroke();
  }

  ctx.setLineDash([]);
}

function renderSelectionBox(ctx: CanvasRenderingContext2D, obj: BoardObject) {
  const pad = 6;
  let x, y, w, h;

  if (obj.type === 'stroke' && obj.points && obj.points.length > 0) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (let i = 0; i < obj.points.length; i += 2) {
      minX = Math.min(minX, obj.points[i]);
      maxX = Math.max(maxX, obj.points[i]);
      minY = Math.min(minY, obj.points[i + 1]);
      maxY = Math.max(maxY, obj.points[i + 1]);
    }
    x = minX - pad; y = minY - pad;
    w = maxX - minX + pad * 2; h = maxY - minY + pad * 2;
  } else if (obj.type === 'arrow') {
    const x2 = obj.x2 ?? obj.x + 100, y2 = obj.y2 ?? obj.y;
    x = Math.min(obj.x, x2) - pad;
    y = Math.min(obj.y, y2) - pad;
    w = Math.abs(x2 - obj.x) + pad * 2;
    h = Math.abs(y2 - obj.y) + pad * 2;
  } else {
    x = obj.x - pad; y = obj.y - pad;
    w = (obj.width || 100) + pad * 2;
    h = (obj.height || 60) + pad * 2;
  }

  ctx.save();
  ctx.strokeStyle = '#4f6ef7';
  ctx.lineWidth = 1.5;
  ctx.setLineDash([5, 3]);
  ctx.strokeRect(x, y, w, h);
  ctx.setLineDash([]);

  // Handles
  const handles = [
    [x, y], [x + w / 2, y], [x + w, y],
    [x, y + h / 2], [x + w, y + h / 2],
    [x, y + h], [x + w / 2, y + h], [x + w, y + h],
  ];
  ctx.fillStyle = '#fff';
  ctx.strokeStyle = '#4f6ef7';
  ctx.lineWidth = 1.5;
  handles.forEach(([hx, hy]) => {
    ctx.fillRect(hx - 4, hy - 4, 8, 8);
    ctx.strokeRect(hx - 4, hy - 4, 8, 8);
  });
  ctx.restore();
}

export function getBoundingBox(obj: BoardObject): { x: number; y: number; w: number; h: number } {
  if (obj.type === 'stroke' && obj.points && obj.points.length > 0) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (let i = 0; i < obj.points.length; i += 2) {
      minX = Math.min(minX, obj.points[i]);
      maxX = Math.max(maxX, obj.points[i]);
      minY = Math.min(minY, obj.points[i + 1]);
      maxY = Math.max(maxY, obj.points[i + 1]);
    }
    return { x: minX, y: minY, w: maxX - minX || 1, h: maxY - minY || 1 };
  }
  if (obj.type === 'arrow') {
    const x2 = obj.x2 ?? obj.x + 100, y2 = obj.y2 ?? obj.y;
    return {
      x: Math.min(obj.x, x2),
      y: Math.min(obj.y, y2),
      w: Math.abs(x2 - obj.x) || 1,
      h: Math.abs(y2 - obj.y) || 1,
    };
  }
  return { x: obj.x, y: obj.y, w: obj.width || 100, h: obj.height || 60 };
}

export function hitTestObject(obj: BoardObject, px: number, py: number, pad = 8): boolean {
  const bb = getBoundingBox(obj);
  return (
    px >= bb.x - pad &&
    px <= bb.x + bb.w + pad &&
    py >= bb.y - pad &&
    py <= bb.y + bb.h + pad
  );
}

export function screenToCanvas(
  sx: number,
  sy: number,
  offsetX: number,
  offsetY: number,
  zoom: number
): { x: number; y: number } {
  return {
    x: (sx - offsetX) / zoom,
    y: (sy - offsetY) / zoom,
  };
}

export function canvasToScreen(
  cx: number,
  cy: number,
  offsetX: number,
  offsetY: number,
  zoom: number
): { x: number; y: number } {
  return {
    x: cx * zoom + offsetX,
    y: cy * zoom + offsetY,
  };
}

export function snapToGrid(val: number, gridSize: number): number {
  return Math.round(val / gridSize) * gridSize;
}
