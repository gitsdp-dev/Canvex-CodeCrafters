import { openDB, IDBPDatabase } from 'idb';

const DB_NAME = 'canvex-db';
const DB_VERSION = 1;
const STORE_SESSIONS = 'sessions';
const STORE_SETTINGS = 'settings';

export interface BoardObject {
  id: string;
  type: 'stroke' | 'shape' | 'text' | 'sticky' | 'image' | 'arrow' | 'connector';
  x: number;
  y: number;
  width?: number;
  height?: number;
  rotation?: number;
  layerId: string;
  locked?: boolean;
  visible?: boolean;
  // Stroke specific
  points?: number[];
  color?: string;
  strokeWidth?: number;
  opacity?: number;
  tool?: string;
  dashArray?: number[];
  // Shape specific
  shapeType?: 'rect' | 'ellipse' | 'triangle' | 'diamond' | 'hexagon' | 'star' | 'line' | 'arrow';
  fillColor?: string;
  filled?: boolean;
  // Text specific
  text?: string;
  fontSize?: number;
  fontFamily?: string;
  fontWeight?: string;
  fontStyle?: string;
  textAlign?: string;
  // Sticky note
  noteColor?: string;
  // Image
  imageData?: string;
  // Arrow/Connector
  x2?: number;
  y2?: number;
  startArrow?: boolean;
  endArrow?: boolean;
  // Task card
  title?: string;
  description?: string;
  status?: string;
  priority?: string;
  checked?: boolean;
  pinned?: boolean;
  connectedTo?: string[];
}

export interface Layer {
  id: string;
  name: string;
  visible: boolean;
  locked: boolean;
  opacity: number;
}

export interface BoardSession {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  thumbnail?: string;
  objects: BoardObject[];
  layers: Layer[];
  activeLayerId: string;
  viewState: {
    offsetX: number;
    offsetY: number;
    zoom: number;
  };
  settings: {
    gridMode: 'none' | 'dots' | 'lines';
    snapToGrid: boolean;
    darkMode: boolean;
    gridSize: number;
  };
  notes: string;
}

export interface AppSettings {
  lastSessionId: string | null;
  darkMode: boolean;
  recentSessions: string[];
}

let db: IDBPDatabase | null = null;

async function getDB() {
  if (db) return db;
  db = await openDB(DB_NAME, DB_VERSION, {
    upgrade(database) {
      if (!database.objectStoreNames.contains(STORE_SESSIONS)) {
        database.createObjectStore(STORE_SESSIONS, { keyPath: 'id' });
      }
      if (!database.objectStoreNames.contains(STORE_SETTINGS)) {
        database.createObjectStore(STORE_SETTINGS);
      }
    },
  });
  return db;
}

export async function saveSession(session: BoardSession): Promise<void> {
  const database = await getDB();
  await database.put(STORE_SESSIONS, session);
  // Update recent sessions list
  const settings = await getAppSettings();
  const recent = settings.recentSessions.filter(id => id !== session.id);
  recent.unshift(session.id);
  await saveAppSettings({ ...settings, lastSessionId: session.id, recentSessions: recent.slice(0, 5) });
}

export async function loadSession(id: string): Promise<BoardSession | null> {
  const database = await getDB();
  return database.get(STORE_SESSIONS, id) || null;
}

export async function getAllSessions(): Promise<BoardSession[]> {
  const database = await getDB();
  return database.getAll(STORE_SESSIONS);
}

export async function deleteSession(id: string): Promise<void> {
  const database = await getDB();
  await database.delete(STORE_SESSIONS, id);
  const settings = await getAppSettings();
  const recent = settings.recentSessions.filter(sid => sid !== id);
  const lastSessionId = settings.lastSessionId === id ? (recent[0] || null) : settings.lastSessionId;
  await saveAppSettings({ ...settings, lastSessionId, recentSessions: recent });
}

export async function getAppSettings(): Promise<AppSettings> {
  try {
    const database = await getDB();
    const settings = await database.get(STORE_SETTINGS, 'app');
    return settings || { lastSessionId: null, darkMode: false, recentSessions: [] };
  } catch {
    return { lastSessionId: null, darkMode: false, recentSessions: [] };
  }
}

export async function saveAppSettings(settings: AppSettings): Promise<void> {
  const database = await getDB();
  await database.put(STORE_SETTINGS, settings, 'app');
}

export function createNewSession(name?: string): BoardSession {
  const id = `session-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const now = Date.now();
  return {
    id,
    name: name || `Board ${new Date().toLocaleDateString()}`,
    createdAt: now,
    updatedAt: now,
    thumbnail: undefined,
    objects: [],
    layers: [
      { id: 'layer-1', name: 'Layer 1', visible: true, locked: false, opacity: 1 }
    ],
    activeLayerId: 'layer-1',
    viewState: { offsetX: 0, offsetY: 0, zoom: 1 },
    settings: {
      gridMode: 'dots',
      snapToGrid: false,
      darkMode: false,
      gridSize: 24,
    },
    notes: '',
  };
}

export function generateId(): string {
  return `obj-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export function generateLayerId(): string {
  return `layer-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}
