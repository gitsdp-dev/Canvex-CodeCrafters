import { useEffect, useRef, useState } from 'react';
import {
  Pen, Grid3X3, Layers, FileDown, Zap, ArrowRight,
  Moon, Sun, Layout, Clock,
  Play, Plus, ChevronRight
} from 'lucide-react';
import { BoardSession, getAllSessions } from '../utils/storage';

interface HomePageProps {
  lastSession: BoardSession | null;
  darkMode: boolean;
  onOpenWorkspace: (session?: BoardSession) => void;
  onNewBoard: () => void;
  onToggleDark: (dark: boolean) => void;
}

const FEATURES = [
  {
    icon: <Pen size={20} />,
    title: 'Advanced Drawing',
    desc: 'Pen, pencil, marker, brush with pressure sensitivity and ultra-smooth rendering.',
    color: '#4f6ef7',
  },
  {
    icon: <Layout size={20} />,
    title: 'Planning Tools',
    desc: 'Kanban boards, mind maps, flowcharts, daily & weekly planners in one canvas.',
    color: '#7c5cfa',
  },
  {
    icon: <Layers size={20} />,
    title: 'Layer System',
    desc: 'Full layer management with visibility, locking, and per-layer opacity control.',
    color: '#0ea5e9',
  },
  {
    icon: <Grid3X3 size={20} />,
    title: 'Infinite Canvas',
    desc: 'Pan, zoom, and navigate with smooth gestures. Dot grid, line grid, and snap-to-grid.',
    color: '#10b981',
  },
  {
    icon: <FileDown size={20} />,
    title: 'Export Anywhere',
    desc: 'Export to PNG, JPG, SVG or PDF. Import images and drag-and-drop files onto the board.',
    color: '#f59e0b',
  },
  {
    icon: <Zap size={20} />,
    title: 'Auto-Save',
    desc: 'Continuous local auto-save with IndexedDB. Sessions persist across browser restarts.',
    color: '#ef4444',
  },
];

function MockupCanvas({ session }: { session: BoardSession | null }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    // Background
    ctx.fillStyle = '#f8f9fb';
    ctx.fillRect(0, 0, W, H);

    // Dot grid
    ctx.fillStyle = '#d1d5e0';
    for (let x = 20; x < W; x += 24) {
      for (let y = 20; y < H; y += 24) {
        ctx.beginPath();
        ctx.arc(x, y, 1, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    if (session && session.objects.length > 0) {
      // Render simplified version of actual objects
      const scaleX = W / 1200;
      const scaleY = H / 700;
      const scale = Math.min(scaleX, scaleY) * 0.8;
      ctx.save();
      ctx.translate(W / 2, H / 2);
      ctx.scale(scale, scale);
      ctx.translate(-600, -350);

      session.objects.slice(0, 30).forEach(obj => {
        if (obj.type === 'stroke' && obj.points && obj.points.length > 2) {
          ctx.beginPath();
          ctx.strokeStyle = obj.color || '#1a1d23';
          ctx.lineWidth = (obj.strokeWidth || 2) / scale;
          ctx.globalAlpha = obj.opacity || 1;
          ctx.moveTo(obj.points[0], obj.points[1]);
          for (let i = 2; i < obj.points.length; i += 2) {
            ctx.lineTo(obj.points[i], obj.points[i + 1]);
          }
          ctx.stroke();
        } else if (obj.type === 'shape') {
          ctx.globalAlpha = obj.opacity || 1;
          ctx.strokeStyle = obj.color || '#1a1d23';
          ctx.lineWidth = (obj.strokeWidth || 2) / scale;
          if (obj.filled && obj.fillColor) {
            ctx.fillStyle = obj.fillColor;
          }
          if (obj.shapeType === 'rect' || !obj.shapeType) {
            if (obj.filled) ctx.fillRect(obj.x, obj.y, obj.width || 100, obj.height || 60);
            ctx.strokeRect(obj.x, obj.y, obj.width || 100, obj.height || 60);
          }
        }
        ctx.globalAlpha = 1;
      });
      ctx.restore();
    } else {
      // Demo content
      drawDemoContent(ctx, W, H);
    }
  }, [session]);

  function drawDemoContent(ctx: CanvasRenderingContext2D, W: number, H: number) {
    // Toolbar hint
    ctx.fillStyle = '#ffffff';
    ctx.shadowColor = 'rgba(0,0,0,0.10)';
    ctx.shadowBlur = 12;
    roundRect(ctx, 16, 16, 44, H - 32, 10);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Tool icons
    const tools = ['#4f6ef7', '#7c5cfa', '#10b981', '#f59e0b', '#ef4444'];
    tools.forEach((c, i) => {
      ctx.fillStyle = i === 0 ? c : '#e2e6ed';
      ctx.beginPath();
      ctx.arc(38, 56 + i * 34, 8, 0, Math.PI * 2);
      ctx.fill();
    });

    // Sample strokes
    ctx.strokeStyle = '#4f6ef7';
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    const wave = [90, 160, 140, 120, 200, 180, 260, 130, 320, 170, 370, 140];
    ctx.moveTo(wave[0], wave[1]);
    for (let i = 2; i < wave.length; i += 2) {
      ctx.lineTo(wave[i], wave[i + 1]);
    }
    ctx.stroke();

    ctx.strokeStyle = '#7c5cfa';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(220, 250, 40, 0, Math.PI * 2);
    ctx.stroke();

    // Sticky notes
    const notes = [
      { x: 320, y: 90, color: '#fef3c7', text: 'Design Review' },
      { x: 420, y: 160, color: '#dbeafe', text: 'Feature Plan' },
      { x: 360, y: 230, color: '#d1fae5', text: 'Completed ✓' },
    ];
    notes.forEach(n => {
      ctx.fillStyle = n.color;
      ctx.shadowColor = 'rgba(0,0,0,0.12)';
      ctx.shadowBlur = 8;
      roundRect(ctx, n.x, n.y, 90, 60, 6);
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#374151';
      ctx.font = '10px Inter, sans-serif';
      ctx.fillText(n.text, n.x + 8, n.y + 24);
    });

    // Kanban board suggestion
    ctx.fillStyle = '#ffffff';
    ctx.shadowColor = 'rgba(0,0,0,0.08)';
    ctx.shadowBlur = 12;
    roundRect(ctx, W - 240, 80, 210, H - 110, 10);
    ctx.fill();
    ctx.shadowBlur = 0;

    const cols = ['To Do', 'In Progress', 'Done'];
    const colColors = ['#e2e6ed', '#dbeafe', '#d1fae5'];
    cols.forEach((label, ci) => {
      const cx = W - 228 + ci * 68;
      ctx.fillStyle = colColors[ci];
      roundRect(ctx, cx, 100, 58, 16, 4);
      ctx.fill();
      ctx.fillStyle = '#374151';
      ctx.font = 'bold 8px Inter, sans-serif';
      ctx.fillText(label, cx + 4, 112);

      for (let ri = 0; ri < 2 + Math.floor(Math.random() * 2); ri++) {
        ctx.fillStyle = '#f8f9fb';
        ctx.shadowColor = 'rgba(0,0,0,0.06)';
        ctx.shadowBlur = 4;
        roundRect(ctx, cx, 126 + ri * 52, 58, 44, 6);
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.fillStyle = '#6b7280';
        ctx.font = '7px Inter, sans-serif';
        ctx.fillText('Task item', cx + 5, 143 + ri * 52);
      }
    });

    // Drawing sample shapes
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2;
    ctx.strokeRect(90, 220, 120, 80);

    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(90, 330);
    ctx.lineTo(210, 310);
    ctx.stroke();

    // Arrow
    ctx.strokeStyle = '#4f6ef7';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(230, 250);
    ctx.lineTo(315, 130);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(315, 130);
    ctx.lineTo(305, 145);
    ctx.moveTo(315, 130);
    ctx.lineTo(328, 140);
    ctx.stroke();

    // Status bar at bottom
    ctx.fillStyle = '#ffffff';
    ctx.shadowColor = 'rgba(0,0,0,0.06)';
    ctx.shadowBlur = 6;
    roundRect(ctx, 0, H - 26, W, 26, 0);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#9399a8';
    ctx.font = '9px Inter, sans-serif';
    ctx.fillText('Zoom 100%  ·  Canvex Workspace  ·  Saved ✓', 72, H - 10);
  }

  return (
    <canvas
      ref={canvasRef}
      width={540}
      height={320}
      style={{
        width: '100%',
        height: 'auto',
        borderRadius: 12,
        display: 'block',
        border: '1px solid var(--color-border)',
      }}
    />
  );
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

export default function HomePage({
  lastSession,
  darkMode,
  onOpenWorkspace,
  onNewBoard,
  onToggleDark,
}: HomePageProps) {
  const [recentSessions, setRecentSessions] = useState<BoardSession[]>([]);

  useEffect(() => {
    getAllSessions().then(sessions => {
      const sorted = sessions.sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 3);
      setRecentSessions(sorted);
    });
  }, [lastSession]);

  const handleContinue = () => {
    if (lastSession) {
      onOpenWorkspace(lastSession);
    } else if (recentSessions.length > 0) {
      onOpenWorkspace(recentSessions[0]);
    } else {
      onNewBoard();
    }
  };

  const displaySession = lastSession || recentSessions[0] || null;
  const hasSession = !!displaySession;

  return (
    <div className="home-page no-select" style={{ background: 'var(--color-bg)', color: 'var(--color-text)' }}>
      {/* NAVBAR */}
      <nav style={{
        position: 'sticky',
        top: 0,
        zIndex: 100,
        background: 'var(--color-surface)',
        borderBottom: '1px solid var(--color-border)',
        boxShadow: 'var(--shadow-sm)',
      }}>
        <div style={{
          maxWidth: 1200,
          margin: '0 auto',
          padding: '0 24px',
          height: 54,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
          {/* Logo */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <div style={{
              width: 30,
              height: 30,
              borderRadius: 8,
              background: 'linear-gradient(135deg, #4f6ef7, #7c5cfa)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
              <Pen size={15} color="white" />
            </div>
            <span style={{ fontWeight: 700, fontSize: 17, letterSpacing: '-0.3px' }}>Canvex</span>
          </div>

          {/* Nav links */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <button
              onClick={() => onToggleDark(!darkMode)}
              className="btn-icon tooltip"
              data-tip={darkMode ? 'Light mode' : 'Dark mode'}
              style={{ marginRight: 4 }}
            >
              {darkMode ? <Sun size={16} /> : <Moon size={16} />}
            </button>
            <button
              onClick={onNewBoard}
              style={{
                height: 34,
                padding: '0 14px',
                borderRadius: 8,
                border: '1px solid var(--color-border)',
                background: 'transparent',
                color: 'var(--color-text)',
                fontFamily: 'inherit',
                fontSize: 13,
                fontWeight: 500,
                cursor: 'pointer',
                transition: 'background 150ms',
              }}
              onMouseEnter={e => (e.currentTarget.style.background = 'var(--color-border)')}
              onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
            >
              New Board
            </button>
            <button
              onClick={handleContinue}
              style={{
                height: 34,
                padding: '0 16px',
                borderRadius: 8,
                border: 'none',
                background: 'linear-gradient(135deg, #4f6ef7, #7c5cfa)',
                color: '#fff',
                fontFamily: 'inherit',
                fontSize: 13,
                fontWeight: 600,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                transition: 'opacity 150ms',
              }}
              onMouseEnter={e => (e.currentTarget.style.opacity = '0.9')}
              onMouseLeave={e => (e.currentTarget.style.opacity = '1')}
            >
              Open App <ArrowRight size={14} />
            </button>
          </div>
        </div>
      </nav>

      {/* HERO */}
      <section style={{ padding: '56px 24px 40px', maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.1fr', gap: 48, alignItems: 'center' }}>
          {/* Left: text */}
          <div className="animate-fade-in">
            <div style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 6,
              padding: '4px 12px',
              borderRadius: 100,
              background: 'color-mix(in srgb, #4f6ef7 10%, transparent)',
              border: '1px solid color-mix(in srgb, #4f6ef7 25%, transparent)',
              color: '#4f6ef7',
              fontSize: 12,
              fontWeight: 600,
              marginBottom: 18,
              letterSpacing: '0.3px',
            }}>
              <Zap size={11} />
              Professional Whiteboard Studio
            </div>

            <h1 style={{
              fontSize: 'clamp(28px, 4vw, 44px)',
              fontWeight: 800,
              lineHeight: 1.15,
              letterSpacing: '-1px',
              margin: '0 0 14px',
              color: 'var(--color-text)',
            }}>
              Think, plan, and draw — all in one place.
            </h1>

            <p style={{
              fontSize: 16,
              color: 'var(--color-muted)',
              lineHeight: 1.65,
              margin: '0 0 28px',
              maxWidth: 400,
            }}>
              A powerful infinite canvas for drawing, planning, and creative work. Fully offline. Everything saves automatically in your browser.
            </p>

            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              <button
                onClick={hasSession ? handleContinue : onNewBoard}
                style={{
                  height: 42,
                  padding: '0 22px',
                  borderRadius: 9,
                  border: 'none',
                  background: 'linear-gradient(135deg, #4f6ef7, #7c5cfa)',
                  color: '#fff',
                  fontFamily: 'inherit',
                  fontSize: 14,
                  fontWeight: 600,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 7,
                  boxShadow: '0 4px 16px rgba(79,110,247,0.35)',
                  transition: 'transform 150ms, box-shadow 150ms',
                }}
                onMouseEnter={e => {
                  e.currentTarget.style.transform = 'translateY(-1px)';
                  e.currentTarget.style.boxShadow = '0 6px 20px rgba(79,110,247,0.45)';
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = '0 4px 16px rgba(79,110,247,0.35)';
                }}
              >
                {hasSession ? <Play size={15} /> : <Plus size={15} />}
                {hasSession ? 'Continue Working' : 'Start Whiteboard'}
              </button>

              {hasSession && (
                <button
                  onClick={onNewBoard}
                  style={{
                    height: 42,
                    padding: '0 20px',
                    borderRadius: 9,
                    border: '1px solid var(--color-border)',
                    background: 'var(--color-surface)',
                    color: 'var(--color-text)',
                    fontFamily: 'inherit',
                    fontSize: 14,
                    fontWeight: 500,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 7,
                    transition: 'background 150ms',
                  }}
                  onMouseEnter={e => (e.currentTarget.style.background = 'var(--color-border)')}
                  onMouseLeave={e => (e.currentTarget.style.background = 'var(--color-surface)')}
                >
                  <Plus size={15} /> New Board
                </button>
              )}
            </div>

            {/* Recent session info */}
            {displaySession && (
              <div style={{
                marginTop: 22,
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                fontSize: 12,
                color: 'var(--color-muted)',
              }}>
                <Clock size={13} />
                <span>
                  Last session: <strong style={{ color: 'var(--color-text)', fontWeight: 600 }}>{displaySession.name}</strong>
                  {' '}· {new Date(displaySession.updatedAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  {' '}· {displaySession.objects.length} objects
                </span>
              </div>
            )}
          </div>

          {/* Right: mockup */}
          <div className="animate-fade-in hero-mockup" style={{ animationDelay: '80ms' }}>
            <div style={{
              background: 'var(--color-surface)',
              borderRadius: 14,
              border: '1px solid var(--color-border)',
              overflow: 'hidden',
              boxShadow: 'var(--shadow-lg)',
            }}>
              {/* Window chrome */}
              <div style={{
                padding: '10px 14px',
                borderBottom: '1px solid var(--color-border)',
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                background: 'var(--color-bg)',
              }}>
                <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#ef4444' }} />
                <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#f59e0b' }} />
                <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#10b981' }} />
                <span style={{
                  marginLeft: 10,
                  fontSize: 11,
                  color: 'var(--color-muted)',
                  fontFamily: 'monospace',
                }}>
                  {displaySession?.name || 'Canvex Workspace'}
                </span>
              </div>
              <MockupCanvas session={displaySession} />
            </div>
          </div>
        </div>
      </section>

      {/* RECENT SESSIONS */}
      {recentSessions.length > 0 && (
        <section style={{ maxWidth: 1200, margin: '0 auto', padding: '0 24px 40px' }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: 14,
          }}>
            <h2 style={{ fontSize: 14, fontWeight: 700, margin: 0, color: 'var(--color-text)' }}>
              Recent Boards
            </h2>
            <button
              onClick={onNewBoard}
              style={{
                fontSize: 12,
                color: '#4f6ef7',
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                fontFamily: 'inherit',
                display: 'flex',
                alignItems: 'center',
                gap: 4,
                fontWeight: 500,
              }}
            >
              <Plus size={13} /> New Board
            </button>
          </div>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
            gap: 12,
          }}>
            {recentSessions.map((sess, i) => (
              <button
                key={sess.id}
                onClick={() => onOpenWorkspace(sess)}
                className="animate-fade-in"
                style={{
                  animationDelay: `${i * 60}ms`,
                  background: 'var(--color-surface)',
                  border: '1px solid var(--color-border)',
                  borderRadius: 10,
                  padding: '14px 16px',
                  cursor: 'pointer',
                  textAlign: 'left',
                  fontFamily: 'inherit',
                  transition: 'transform 150ms, box-shadow 150ms',
                  color: 'var(--color-text)',
                }}
                onMouseEnter={e => {
                  e.currentTarget.style.transform = 'translateY(-2px)';
                  e.currentTarget.style.boxShadow = 'var(--shadow-md)';
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = 'none';
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                  <div style={{
                    width: 32,
                    height: 32,
                    borderRadius: 7,
                    background: `hsl(${i * 60 + 200}, 70%, 92%)`,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                    <Layout size={15} style={{ color: `hsl(${i * 60 + 200}, 60%, 45%)` }} />
                  </div>
                  <ChevronRight size={14} style={{ color: 'var(--color-muted)', marginTop: 2 }} />
                </div>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 3, lineHeight: 1.3 }}>
                  {sess.name}
                </div>
                <div style={{ fontSize: 11, color: 'var(--color-muted)' }}>
                  {sess.objects.length} objects · {new Date(sess.updatedAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                </div>
              </button>
            ))}
          </div>
        </section>
      )}

      {/* FEATURES GRID */}
      <section style={{ maxWidth: 1200, margin: '0 auto', padding: '0 24px 60px' }}>
        <div style={{ marginBottom: 28, textAlign: 'center' }}>
          <h2 style={{ fontSize: 24, fontWeight: 800, letterSpacing: '-0.5px', margin: '0 0 8px' }}>
            Everything you need in one canvas
          </h2>
          <p style={{ fontSize: 14, color: 'var(--color-muted)', margin: 0 }}>
            Drawing, planning, and productivity tools — all built in.
          </p>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(3, 1fr)',
          gap: 14,
        }}>
          {FEATURES.map((feat, i) => (
            <div
              key={feat.title}
              className="feature-card animate-fade-in"
              style={{
                animationDelay: `${i * 50}ms`,
                background: 'var(--color-surface)',
                border: '1px solid var(--color-border)',
                borderRadius: 10,
                padding: '18px 20px',
                boxShadow: 'var(--shadow-sm)',
              }}
            >
              <div style={{
                width: 36,
                height: 36,
                borderRadius: 9,
                background: `${feat.color}18`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: 12,
                color: feat.color,
              }}>
                {feat.icon}
              </div>
              <h3 style={{ fontSize: 14, fontWeight: 700, margin: '0 0 6px' }}>{feat.title}</h3>
              <p style={{ fontSize: 13, color: 'var(--color-muted)', margin: 0, lineHeight: 1.55 }}>{feat.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{
        borderTop: '1px solid var(--color-border)',
        padding: '16px 24px',
        maxWidth: 1200,
        margin: '0 auto',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: 8,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{
            width: 22,
            height: 22,
            borderRadius: 6,
            background: 'linear-gradient(135deg, #4f6ef7, #7c5cfa)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
            <Pen size={11} color="white" />
          </div>
          <span style={{ fontSize: 13, fontWeight: 600 }}>Canvex</span>
          <span style={{ fontSize: 12, color: 'var(--color-muted)' }}>· Fully local, fully private.</span>
        </div>
        <div style={{ display: 'flex', gap: 16, fontSize: 12, color: 'var(--color-muted)' }}>
          <span>No account needed</span>
          <span>·</span>
          <span>Works offline</span>
          <span>·</span>
          <span>Open source friendly</span>
        </div>
      </footer>

      {/* Mobile responsive overrides */}
      <style>{`
        @media (max-width: 768px) {
          section > div[style*="grid-template-columns: 1fr 1.1fr"] {
            grid-template-columns: 1fr !important;
          }
          section > div[style*="grid-template-columns: repeat(3"] {
            grid-template-columns: 1fr 1fr !important;
          }
          .hero-mockup { display: none !important; }
        }
        @media (max-width: 520px) {
          section > div[style*="grid-template-columns: 1fr 1fr"] {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </div>
  );
}
