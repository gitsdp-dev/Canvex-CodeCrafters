import { useState } from 'react';
import {
  Pen, Home, Undo2, Redo2, Download, Upload,
  Moon, Sun, Grid3X3, Dot, AlignJustify, Magnet,
  Maximize, Command, Save, ChevronDown, Image,
  FileText, FileImage, Plus, Trash2,
} from 'lucide-react';
import { BoardSession } from '../utils/storage';

interface WorkspaceHeaderProps {
  session: BoardSession;
  darkMode: boolean;
  canUndo: boolean;
  canRedo: boolean;
  saveStatus: 'saved' | 'saving' | 'unsaved';
  onUndo: () => void;
  onRedo: () => void;
  onReturnHome: () => void;
  onToggleDark: (dark: boolean) => void;
  onGridModeChange: (mode: 'none' | 'dots' | 'lines') => void;
  onSnapToggle: () => void;
  onFullscreen: () => void;
  onExport: (format: 'png' | 'jpg' | 'svg' | 'pdf') => void;
  onImportImage: () => void;
  onSaveBoard: () => void;
  onLoadBoard: () => void;
  onNewBoard: () => void;
  onRenameBoard: (name: string) => void;
  onClearCanvas: () => void;
  onCommandPalette: () => void;
  zoomLevel: number;
  onZoomChange?: (z: number) => void;
  onZoomReset: () => void;
}

export default function WorkspaceHeader({
  session,
  darkMode,
  canUndo,
  canRedo,
  saveStatus,
  onUndo,
  onRedo,
  onReturnHome,
  onToggleDark,
  onGridModeChange,
  onSnapToggle,
  onFullscreen,
  onExport,
  onImportImage,
  onSaveBoard,
  onLoadBoard,
  onNewBoard,
  onRenameBoard,
  onClearCanvas,
  onCommandPalette,
  zoomLevel,
  onZoomReset,
}: WorkspaceHeaderProps) {
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [showFileMenu, setShowFileMenu] = useState(false);
  const [editingName, setEditingName] = useState(false);
  const [tempName, setTempName] = useState(session.name);

  const gridMode = session.settings.gridMode;

  const gridModes: Array<'none' | 'dots' | 'lines'> = ['none', 'dots', 'lines'];
  const nextGrid = gridModes[(gridModes.indexOf(gridMode) + 1) % gridModes.length];

  const GridIcon = gridMode === 'dots' ? Dot : gridMode === 'lines' ? AlignJustify : Grid3X3;

  const zoomPercent = Math.round(zoomLevel * 100);



  return (
    <div style={{
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      height: 52,
      zIndex: 300,
      background: 'var(--color-surface)',
      borderBottom: '1px solid var(--color-border)',
      display: 'flex',
      alignItems: 'center',
      padding: '0 12px',
      gap: 4,
      boxShadow: 'var(--shadow-sm)',
    }}>
      {/* Logo / Home */}
      <button
        onClick={onReturnHome}
        className="btn-icon tooltip"
        data-tip="Home"
        style={{ marginRight: 2 }}
      >
        <Home size={16} />
      </button>

      <div style={{ width: 1, height: 20, background: 'var(--color-border)', margin: '0 4px' }} />

      {/* File menu */}
      <div style={{ position: 'relative' }}>
        <button
          onClick={() => { setShowFileMenu(s => !s); setShowExportMenu(false); }}
          style={{
            height: 30,
            padding: '0 10px',
            borderRadius: 6,
            border: '1px solid var(--color-border)',
            background: showFileMenu ? 'var(--color-border)' : 'transparent',
            color: 'var(--color-text)',
            fontFamily: 'inherit',
            fontSize: 12,
            fontWeight: 500,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: 4,
          }}
        >
          File <ChevronDown size={11} />
        </button>
        {showFileMenu && (
          <div className="context-menu" style={{ top: 34, left: 0, minWidth: 180 }}>
            <div className="context-menu-item" onClick={() => { onNewBoard(); setShowFileMenu(false); }}>
              <Plus size={14} /> New Board
            </div>
            <div className="context-menu-separator" />
            <div className="context-menu-item" onClick={() => { onSaveBoard(); setShowFileMenu(false); }}>
              <Save size={14} /> Save to File
            </div>
            <div className="context-menu-item" onClick={() => { onLoadBoard(); setShowFileMenu(false); }}>
              <Upload size={14} /> Load from File
            </div>
            <div className="context-menu-separator" />
            <div className="context-menu-item" onClick={() => { onImportImage(); setShowFileMenu(false); }}>
              <Image size={14} /> Import Image
            </div>
            <div className="context-menu-separator" />
            <div className="context-menu-item danger" onClick={() => { onClearCanvas(); setShowFileMenu(false); }}>
              <Trash2 size={14} /> Clear Canvas
            </div>
          </div>
        )}
      </div>

      {/* Export */}
      <div style={{ position: 'relative' }}>
        <button
          onClick={() => { setShowExportMenu(s => !s); setShowFileMenu(false); }}
          style={{
            height: 30,
            padding: '0 10px',
            borderRadius: 6,
            border: '1px solid var(--color-border)',
            background: showExportMenu ? 'var(--color-border)' : 'transparent',
            color: 'var(--color-text)',
            fontFamily: 'inherit',
            fontSize: 12,
            fontWeight: 500,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: 4,
          }}
        >
          <Download size={13} /> Export <ChevronDown size={11} />
        </button>
        {showExportMenu && (
          <div className="context-menu" style={{ top: 34, left: 0, minWidth: 140 }}>
            {(['png', 'jpg', 'svg', 'pdf'] as const).map(fmt => (
              <div
                key={fmt}
                className="context-menu-item"
                onClick={() => { onExport(fmt); setShowExportMenu(false); }}
              >
                {fmt === 'pdf' ? <FileText size={14} /> : <FileImage size={14} />}
                Export as {fmt.toUpperCase()}
              </div>
            ))}
          </div>
        )}
      </div>

      <div style={{ width: 1, height: 20, background: 'var(--color-border)', margin: '0 4px' }} />

      {/* Undo / Redo */}
      <button
        className="btn-icon tooltip"
        data-tip="Undo (Ctrl+Z)"
        onClick={onUndo}
        disabled={!canUndo}
        style={{ opacity: canUndo ? 1 : 0.35 }}
      >
        <Undo2 size={15} />
      </button>
      <button
        className="btn-icon tooltip"
        data-tip="Redo (Ctrl+Y)"
        onClick={onRedo}
        disabled={!canRedo}
        style={{ opacity: canRedo ? 1 : 0.35 }}
      >
        <Redo2 size={15} />
      </button>

      <div style={{ width: 1, height: 20, background: 'var(--color-border)', margin: '0 4px' }} />

      {/* Grid mode */}
      <button
        className="btn-icon tooltip"
        data-tip={`Grid: ${gridMode} → ${nextGrid}`}
        onClick={() => onGridModeChange(nextGrid)}
        style={{ color: gridMode !== 'none' ? '#4f6ef7' : undefined }}
      >
        <GridIcon size={15} />
      </button>

      {/* Snap */}
      <button
        className={`btn-icon tooltip ${session.settings.snapToGrid ? 'active' : ''}`}
        data-tip="Snap to grid"
        onClick={onSnapToggle}
      >
        <Magnet size={15} />
      </button>

      {/* Flex spacer */}
      <div style={{ flex: 1 }} />

      {/* Board name */}
      {editingName ? (
        <input
          autoFocus
          value={tempName}
          onChange={e => setTempName(e.target.value)}
          onBlur={() => {
            onRenameBoard(tempName || session.name);
            setEditingName(false);
          }}
          onKeyDown={e => {
            if (e.key === 'Enter') {
              onRenameBoard(tempName || session.name);
              setEditingName(false);
            }
            if (e.key === 'Escape') {
              setTempName(session.name);
              setEditingName(false);
            }
          }}
          style={{
            background: 'var(--color-bg)',
            border: '1px solid #4f6ef7',
            borderRadius: 6,
            padding: '3px 8px',
            fontSize: 13,
            fontFamily: 'inherit',
            fontWeight: 600,
            color: 'var(--color-text)',
            outline: 'none',
            minWidth: 160,
            textAlign: 'center',
          }}
        />
      ) : (
        <button
          onClick={() => { setTempName(session.name); setEditingName(true); }}
          style={{
            background: 'none',
            border: 'none',
            fontFamily: 'inherit',
            fontSize: 13,
            fontWeight: 600,
            color: 'var(--color-text)',
            cursor: 'pointer',
            padding: '3px 8px',
            borderRadius: 6,
            transition: 'background 150ms',
          }}
          onMouseEnter={e => (e.currentTarget.style.background = 'var(--color-border)')}
          onMouseLeave={e => (e.currentTarget.style.background = 'none')}
        >
          {session.name}
        </button>
      )}

      {/* Flex spacer */}
      <div style={{ flex: 1 }} />

      {/* Save status */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: 'var(--color-muted)' }}>
        {saveStatus === 'saving' && (
          <>
            <div className="animate-pulse-dot" style={{ width: 6, height: 6, borderRadius: '50%', background: '#f59e0b' }} />
            <span>Saving…</span>
          </>
        )}
        {saveStatus === 'saved' && (
          <>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#10b981' }} />
            <span>Saved</span>
          </>
        )}
        {saveStatus === 'unsaved' && (
          <>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#ef4444' }} />
            <span>Unsaved</span>
          </>
        )}
      </div>

      <div style={{ width: 1, height: 20, background: 'var(--color-border)', margin: '0 4px' }} />

      {/* Zoom control */}
      <div style={{ position: 'relative' }}>
        <button
          onClick={onZoomReset}
          style={{
            height: 28,
            padding: '0 8px',
            borderRadius: 6,
            border: '1px solid var(--color-border)',
            background: 'transparent',
            color: 'var(--color-text)',
            fontFamily: 'monospace',
            fontSize: 12,
            cursor: 'pointer',
            minWidth: 58,
            textAlign: 'center',
          }}
          title="Click to reset zoom"
        >
          {zoomPercent}%
        </button>
      </div>

      {/* Command palette */}
      <button
        className="btn-icon tooltip"
        data-tip="Command Palette (Ctrl+K)"
        onClick={onCommandPalette}
      >
        <Command size={15} />
      </button>

      {/* Fullscreen */}
      <button
        className="btn-icon tooltip"
        data-tip="Fullscreen (F11)"
        onClick={onFullscreen}
      >
        <Maximize size={15} />
      </button>

      {/* Dark mode */}
      <button
        className="btn-icon tooltip"
        data-tip={darkMode ? 'Light mode' : 'Dark mode'}
        onClick={() => onToggleDark(!darkMode)}
      >
        {darkMode ? <Sun size={15} /> : <Moon size={15} />}
      </button>

      {/* Logo */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        marginLeft: 4,
        paddingLeft: 8,
        borderLeft: '1px solid var(--color-border)',
      }}>
        <div style={{
          width: 26,
          height: 26,
          borderRadius: 7,
          background: 'linear-gradient(135deg, #4f6ef7, #7c5cfa)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
          <Pen size={13} color="white" />
        </div>
      </div>

      {/* Click outside handler */}
      {(showExportMenu || showFileMenu) && (
        <div
          style={{ position: 'fixed', inset: 0, zIndex: 998 }}
          onClick={() => { setShowExportMenu(false); setShowFileMenu(false); }}
        />
      )}
    </div>
  );
}
