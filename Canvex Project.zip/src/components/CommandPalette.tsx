import { useState, useEffect, useRef } from 'react';
import { Search, Command } from 'lucide-react';

interface CommandItem {
  id: string;
  label: string;
  shortcut?: string;
  category: string;
  action: () => void;
}

interface CommandPaletteProps {
  commands: CommandItem[];
  onClose: () => void;
}

export default function CommandPalette({ commands, onClose }: CommandPaletteProps) {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const filtered = query.trim()
    ? commands.filter(c =>
      c.label.toLowerCase().includes(query.toLowerCase()) ||
      c.category.toLowerCase().includes(query.toLowerCase())
    )
    : commands.slice(0, 12);

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(i => Math.min(i + 1, filtered.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(i => Math.max(i - 1, 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filtered[selectedIndex]) {
        filtered[selectedIndex].action();
        onClose();
      }
    } else if (e.key === 'Escape') {
      onClose();
    }
  };

  // Group by category
  const grouped = filtered.reduce((acc, cmd) => {
    if (!acc[cmd.category]) acc[cmd.category] = [];
    acc[cmd.category].push(cmd);
    return acc;
  }, {} as Record<string, CommandItem[]>);

  let globalIndex = 0;

  return (
    <div className="cmd-overlay" onClick={onClose}>
      <div
        className="panel animate-scale-in"
        style={{ width: 540, maxHeight: 420, display: 'flex', flexDirection: 'column', overflow: 'hidden', borderRadius: 12 }}
        onClick={e => e.stopPropagation()}
      >
        {/* Search */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          padding: '12px 16px',
          borderBottom: '1px solid var(--color-border)',
        }}>
          <Search size={16} style={{ color: 'var(--color-muted)', flexShrink: 0 }} />
          <input
            ref={inputRef}
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Search commands…"
            style={{
              flex: 1,
              background: 'none',
              border: 'none',
              outline: 'none',
              fontFamily: 'inherit',
              fontSize: 15,
              color: 'var(--color-text)',
            }}
          />
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: 3,
            fontSize: 11,
            color: 'var(--color-muted)',
          }}>
            <Command size={11} />
            <span>K</span>
          </div>
        </div>

        {/* Results */}
        <div ref={listRef} style={{ flex: 1, overflowY: 'auto', padding: '6px' }}>
          {filtered.length === 0 && (
            <div style={{ textAlign: 'center', padding: '24px', color: 'var(--color-muted)', fontSize: 13 }}>
              No commands found
            </div>
          )}
          {Object.entries(grouped).map(([category, items]) => (
            <div key={category}>
              <div style={{
                fontSize: 10,
                fontWeight: 700,
                color: 'var(--color-muted)',
                padding: '6px 10px 3px',
                letterSpacing: '0.6px',
              }}>
                {category.toUpperCase()}
              </div>
              {items.map(cmd => {
                const isSelected = selectedIndex === globalIndex;
                const currentIndex = globalIndex++;
                return (
                  <div
                    key={cmd.id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '8px 10px',
                      borderRadius: 7,
                      cursor: 'pointer',
                      background: isSelected ? 'color-mix(in srgb, #4f6ef7 10%, transparent)' : 'transparent',
                      transition: 'background 100ms',
                    }}
                    onMouseEnter={() => setSelectedIndex(currentIndex)}
                    onClick={() => { cmd.action(); onClose(); }}
                  >
                    <span style={{ fontSize: 13, color: 'var(--color-text)' }}>{cmd.label}</span>
                    {cmd.shortcut && (
                      <kbd style={{
                        fontSize: 11,
                        background: 'var(--color-border)',
                        border: '1px solid var(--color-border)',
                        borderRadius: 4,
                        padding: '1px 6px',
                        color: 'var(--color-muted)',
                        fontFamily: 'monospace',
                      }}>
                        {cmd.shortcut}
                      </kbd>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>

        <div style={{
          display: 'flex',
          gap: 12,
          padding: '8px 16px',
          borderTop: '1px solid var(--color-border)',
          fontSize: 11,
          color: 'var(--color-muted)',
        }}>
          <span>↑↓ Navigate</span>
          <span>↵ Execute</span>
          <span>Esc Close</span>
        </div>
      </div>
    </div>
  );
}

export type { CommandItem };
