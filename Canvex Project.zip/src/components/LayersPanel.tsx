import { useState } from 'react';
import {
  Layers, Eye, EyeOff, Lock, Unlock, Plus, Trash2,
  ChevronUp, ChevronDown, GripVertical, X,
} from 'lucide-react';
import { Layer, generateLayerId } from '../utils/storage';

interface LayersPanelProps {
  layers: Layer[];
  activeLayerId: string;
  onLayersChange: (layers: Layer[]) => void;
  onActiveLayerChange: (id: string) => void;
  onClose: () => void;
}

export default function LayersPanel({
  layers,
  activeLayerId,
  onLayersChange,
  onActiveLayerChange,
  onClose,
}: LayersPanelProps) {
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [tempName, setTempName] = useState('');

  const addLayer = () => {
    const newLayer: Layer = {
      id: generateLayerId(),
      name: `Layer ${layers.length + 1}`,
      visible: true,
      locked: false,
      opacity: 1,
    };
    const updated = [...layers, newLayer];
    onLayersChange(updated);
    onActiveLayerChange(newLayer.id);
  };

  const removeLayer = (id: string) => {
    if (layers.length <= 1) return;
    const updated = layers.filter(l => l.id !== id);
    onLayersChange(updated);
    if (activeLayerId === id) {
      onActiveLayerChange(updated[updated.length - 1].id);
    }
  };

  const toggleVisibility = (id: string) => {
    const updated = layers.map(l => l.id === id ? { ...l, visible: !l.visible } : l);
    onLayersChange(updated);
  };

  const toggleLock = (id: string) => {
    const updated = layers.map(l => l.id === id ? { ...l, locked: !l.locked } : l);
    onLayersChange(updated);
  };

  const moveLayer = (id: string, dir: 'up' | 'down') => {
    const idx = layers.findIndex(l => l.id === id);
    if (dir === 'up' && idx === layers.length - 1) return;
    if (dir === 'down' && idx === 0) return;

    const updated = [...layers];
    const swap = dir === 'up' ? idx + 1 : idx - 1;
    [updated[idx], updated[swap]] = [updated[swap], updated[idx]];
    onLayersChange(updated);
  };

  const updateOpacity = (id: string, opacity: number) => {
    const updated = layers.map(l => l.id === id ? { ...l, opacity } : l);
    onLayersChange(updated);
  };

  const startRename = (layer: Layer) => {
    setRenamingId(layer.id);
    setTempName(layer.name);
  };

  const commitRename = (id: string) => {
    const updated = layers.map(l => l.id === id ? { ...l, name: tempName || l.name } : l);
    onLayersChange(updated);
    setRenamingId(null);
  };

  // Render layers in reverse order (top layers first visually)
  const reversedLayers = [...layers].reverse();

  return (
    <div className="panel animate-slide-right" style={{
      position: 'absolute',
      right: 12,
      top: 60,
      width: 220,
      zIndex: 200,
      overflow: 'hidden',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '10px 12px 8px',
        borderBottom: '1px solid var(--color-border)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, fontWeight: 700, fontSize: 13 }}>
          <Layers size={14} style={{ color: '#4f6ef7' }} />
          Layers
        </div>
        <div style={{ display: 'flex', gap: 4 }}>
          <button className="btn-icon tooltip" data-tip="Add layer" onClick={addLayer} style={{ width: 26, height: 26 }}>
            <Plus size={13} />
          </button>
          <button className="btn-icon" onClick={onClose} style={{ width: 26, height: 26 }}>
            <X size={13} />
          </button>
        </div>
      </div>

      {/* Layer list */}
      <div style={{ maxHeight: 340, overflowY: 'auto', padding: '4px' }}>
        {reversedLayers.map(layer => (
          <div
            key={layer.id}
            className={`layer-item ${activeLayerId === layer.id ? 'active' : ''}`}
            onClick={() => onActiveLayerChange(layer.id)}
          >
            <GripVertical size={12} style={{ color: 'var(--color-muted)', cursor: 'grab' }} />

            {/* Visibility */}
            <button
              className="btn-icon"
              onClick={e => { e.stopPropagation(); toggleVisibility(layer.id); }}
              style={{ width: 22, height: 22, opacity: layer.visible ? 1 : 0.4 }}
            >
              {layer.visible ? <Eye size={12} /> : <EyeOff size={12} />}
            </button>

            {/* Name */}
            <div style={{ flex: 1, minWidth: 0 }}>
              {renamingId === layer.id ? (
                <input
                  autoFocus
                  value={tempName}
                  onChange={e => setTempName(e.target.value)}
                  onBlur={() => commitRename(layer.id)}
                  onKeyDown={e => {
                    if (e.key === 'Enter') commitRename(layer.id);
                    if (e.key === 'Escape') setRenamingId(null);
                    e.stopPropagation();
                  }}
                  onClick={e => e.stopPropagation()}
                  style={{
                    width: '100%',
                    background: 'var(--color-bg)',
                    border: '1px solid #4f6ef7',
                    borderRadius: 4,
                    padding: '1px 4px',
                    fontSize: 12,
                    fontFamily: 'inherit',
                    color: 'var(--color-text)',
                    outline: 'none',
                  }}
                />
              ) : (
                <span
                  style={{
                    fontSize: 12,
                    fontWeight: activeLayerId === layer.id ? 600 : 400,
                    display: 'block',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                    opacity: layer.visible ? 1 : 0.5,
                  }}
                  onDoubleClick={e => { e.stopPropagation(); startRename(layer); }}
                >
                  {layer.name}
                </span>
              )}
            </div>

            {/* Lock */}
            <button
              className="btn-icon"
              onClick={e => { e.stopPropagation(); toggleLock(layer.id); }}
              style={{ width: 22, height: 22, color: layer.locked ? '#f59e0b' : undefined }}
            >
              {layer.locked ? <Lock size={12} /> : <Unlock size={12} />}
            </button>

            {/* Move */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
              <button
                className="btn-icon"
                onClick={e => { e.stopPropagation(); moveLayer(layer.id, 'up'); }}
                style={{ width: 16, height: 14, borderRadius: 2 }}
              >
                <ChevronUp size={10} />
              </button>
              <button
                className="btn-icon"
                onClick={e => { e.stopPropagation(); moveLayer(layer.id, 'down'); }}
                style={{ width: 16, height: 14, borderRadius: 2 }}
              >
                <ChevronDown size={10} />
              </button>
            </div>

            {/* Delete */}
            {layers.length > 1 && (
              <button
                className="btn-icon"
                onClick={e => { e.stopPropagation(); removeLayer(layer.id); }}
                style={{ width: 22, height: 22, color: '#ef4444' }}
              >
                <Trash2 size={11} />
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Opacity for active layer */}
      {(() => {
        const active = layers.find(l => l.id === activeLayerId);
        if (!active) return null;
        return (
          <div style={{ padding: '8px 12px', borderTop: '1px solid var(--color-border)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 11, color: 'var(--color-muted)', minWidth: 50 }}>
                Opacity
              </span>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={active.opacity}
                onChange={e => updateOpacity(activeLayerId, Number(e.target.value))}
                style={{ flex: 1, accentColor: '#4f6ef7' }}
              />
              <span style={{ fontSize: 11, color: 'var(--color-muted)', minWidth: 30, textAlign: 'right' }}>
                {Math.round(active.opacity * 100)}%
              </span>
            </div>
          </div>
        );
      })()}
    </div>
  );
}
