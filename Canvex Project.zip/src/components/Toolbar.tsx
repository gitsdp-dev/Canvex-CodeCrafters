import { useState } from 'react';
import {
  Pen, PenLine, Highlighter, Eraser, MousePointer2,
  Square, Circle, Triangle, Minus, MoveRight,
  Type, StickyNote, Lasso, Move,
  Pipette, Palette,
} from 'lucide-react';

export type ToolType =
  | 'select' | 'pan'
  | 'pen' | 'pencil' | 'marker' | 'brush' | 'eraser'
  | 'rect' | 'ellipse' | 'triangle' | 'diamond' | 'hexagon' | 'star'
  | 'line' | 'arrow'
  | 'text' | 'sticky' | 'lasso'
  | 'eyedropper'
  | string;

interface ToolbarProps {
  activeTool: ToolType;
  onToolChange: (tool: ToolType) => void;
  color: string;
  onColorChange: (color: string) => void;
  strokeWidth: number;
  onStrokeWidthChange: (w: number) => void;
  opacity: number;
  onOpacityChange: (o: number) => void;
  fillColor: string;
  onFillColorChange: (c: string) => void;
  filled: boolean;
  onFilledChange: (f: boolean) => void;
  dashArray: number[];
  onDashArrayChange: (d: number[]) => void;
}

const STROKE_COLORS = [
  '#1a1d23', '#ef4444', '#f59e0b', '#10b981', '#3b82f6',
  '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16', '#f97316',
  '#ffffff', '#6b7280',
];

const FILL_COLORS = [
  'transparent', '#fef3c7', '#dbeafe', '#d1fae5', '#fce7f3',
  '#ede9fe', '#cffafe', '#fee2e2', '#f3f4f6',
];

const TOOL_GROUPS = [
  {
    label: 'Select',
    tools: [
      { id: 'select' as ToolType, icon: <MousePointer2 size={16} />, tip: 'Select (V)' },
      { id: 'lasso' as ToolType, icon: <Lasso size={16} />, tip: 'Lasso (L)' },
      { id: 'pan' as ToolType, icon: <Move size={16} />, tip: 'Pan (Space)' },
    ],
  },
  {
    label: 'Draw',
    tools: [
      { id: 'pen' as ToolType, icon: <Pen size={16} />, tip: 'Pen (P)' },
      { id: 'pencil' as ToolType, icon: <PenLine size={16} />, tip: 'Pencil (N)' },
      { id: 'marker' as ToolType, icon: <Highlighter size={16} />, tip: 'Marker (M)' },
      { id: 'eraser' as ToolType, icon: <Eraser size={16} />, tip: 'Eraser (E)' },
    ],
  },
  {
    label: 'Shapes',
    tools: [
      { id: 'rect' as ToolType, icon: <Square size={16} />, tip: 'Rectangle (R)' },
      { id: 'ellipse' as ToolType, icon: <Circle size={16} />, tip: 'Ellipse (O)' },
      { id: 'triangle' as ToolType, icon: <Triangle size={16} />, tip: 'Triangle' },
      { id: 'diamond' as ToolType, icon: <div style={{ fontSize: 14, fontWeight: 700, lineHeight: 1 }}>◇</div>, tip: 'Diamond' },
      { id: 'line' as ToolType, icon: <Minus size={16} />, tip: 'Line' },
      { id: 'arrow' as ToolType, icon: <MoveRight size={16} />, tip: 'Arrow (A)' },
    ],
  },
  {
    label: 'Content',
    tools: [
      { id: 'text' as ToolType, icon: <Type size={16} />, tip: 'Text (T)' },
      { id: 'sticky' as ToolType, icon: <StickyNote size={16} />, tip: 'Sticky Note (S)' },
    ],
  },
  {
    label: 'Utils',
    tools: [
      { id: 'eyedropper' as ToolType, icon: <Pipette size={16} />, tip: 'Eyedropper (I)' },
    ],
  },
];

const DASH_PRESETS = [
  { label: 'Solid', value: [] },
  { label: 'Dashed', value: [8, 4] },
  { label: 'Dotted', value: [2, 4] },
  { label: 'Long dash', value: [16, 6] },
];

export default function Toolbar({
  activeTool,
  onToolChange,
  color,
  onColorChange,
  strokeWidth,
  onStrokeWidthChange,
  opacity,
  onOpacityChange,
  fillColor,
  onFillColorChange,
  filled,
  onFilledChange,
  dashArray,
  onDashArrayChange,
}: ToolbarProps) {
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [showFillPicker, setShowFillPicker] = useState(false);
  const [customColor, setCustomColor] = useState(color);

  const drawingTools = ['pen', 'pencil', 'marker', 'brush', 'eraser', 'rect', 'ellipse', 'triangle', 'diamond', 'hexagon', 'star', 'line', 'arrow'];
  const isDrawingTool = drawingTools.includes(activeTool);
  const isShapeTool = ['rect', 'ellipse', 'triangle', 'diamond', 'hexagon', 'star'].includes(activeTool);

  return (
    <div style={{
      position: 'absolute',
      left: 12,
      top: '50%',
      transform: 'translateY(-50%)',
      zIndex: 200,
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
    }}>
      <div className="panel" style={{
        display: 'flex',
        flexDirection: 'column',
        padding: '6px 5px',
        gap: 2,
        width: 44,
      }}>
        {TOOL_GROUPS.map((group, gi) => (
          <div key={group.label}>
            {gi > 0 && (
              <div style={{ height: 1, background: 'var(--color-border)', margin: '4px 0' }} />
            )}
            {group.tools.map(tool => (
              <button
                key={tool.id}
                className={`btn-icon tooltip ${activeTool === tool.id ? 'active' : ''}`}
                data-tip={tool.tip}
                onClick={() => onToolChange(tool.id)}
                style={{ width: 34, height: 34 }}
              >
                {tool.icon}
              </button>
            ))}
          </div>
        ))}

        <div style={{ height: 1, background: 'var(--color-border)', margin: '4px 0' }} />

        {/* Color swatch */}
        <div style={{ position: 'relative' }}>
          <button
            className="btn-icon tooltip"
            data-tip="Stroke color"
            onClick={() => {
              setShowColorPicker(s => !s);
              setShowFillPicker(false);
            }}
            style={{ width: 34, height: 34 }}
          >
            <div style={{
              width: 18,
              height: 18,
              borderRadius: '50%',
              background: color,
              border: '2px solid var(--color-border)',
            }} />
          </button>

          {showColorPicker && (
            <div className="panel animate-scale-in" style={{
              position: 'absolute',
              left: 42,
              top: 0,
              padding: 12,
              width: 200,
              zIndex: 999,
            }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--color-muted)', marginBottom: 8 }}>STROKE COLOR</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 10 }}>
                {STROKE_COLORS.map(c => (
                  <button
                    key={c}
                    className={`color-swatch ${color === c ? 'active' : ''}`}
                    style={{
                      background: c,
                      border: `2px solid ${color === c ? '#4f6ef7' : 'var(--color-border)'}`,
                    }}
                    onClick={() => {
                      onColorChange(c);
                      setCustomColor(c);
                    }}
                  />
                ))}
              </div>
              <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                <Palette size={13} style={{ color: 'var(--color-muted)' }} />
                <input
                  type="color"
                  value={customColor}
                  onChange={e => {
                    setCustomColor(e.target.value);
                    onColorChange(e.target.value);
                  }}
                  style={{ width: '100%', height: 28, border: 'none', padding: 0, borderRadius: 4, cursor: 'pointer' }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Fill color (shapes only) */}
        {isShapeTool && (
          <div style={{ position: 'relative' }}>
            <button
              className="btn-icon tooltip"
              data-tip="Fill color"
              onClick={() => {
                setShowFillPicker(s => !s);
                setShowColorPicker(false);
              }}
              style={{ width: 34, height: 34 }}
            >
              <div style={{
                width: 18,
                height: 18,
                borderRadius: 3,
                background: filled ? fillColor : 'transparent',
                border: `2px solid ${filled ? fillColor : 'var(--color-border)'}`,
                position: 'relative',
              }}>
                {!filled && (
                  <div style={{
                    position: 'absolute',
                    inset: -2,
                    borderRadius: 2,
                    background: 'linear-gradient(135deg, transparent 45%, red 45%, red 55%, transparent 55%)',
                    pointerEvents: 'none',
                  }} />
                )}
              </div>
            </button>
            {showFillPicker && (
              <div className="panel animate-scale-in" style={{
                position: 'absolute',
                left: 42,
                top: 0,
                padding: 12,
                width: 180,
                zIndex: 999,
              }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--color-muted)', marginBottom: 8 }}>FILL</div>
                <button
                  onClick={() => onFilledChange(!filled)}
                  style={{
                    width: '100%',
                    padding: '5px 8px',
                    borderRadius: 6,
                    border: '1px solid var(--color-border)',
                    background: filled ? 'color-mix(in srgb, #4f6ef7 12%, transparent)' : 'transparent',
                    color: 'var(--color-text)',
                    fontFamily: 'inherit',
                    fontSize: 12,
                    cursor: 'pointer',
                    marginBottom: 8,
                    textAlign: 'left',
                  }}
                >
                  {filled ? '✓ Filled' : '○ No fill'}
                </button>
                {filled && (
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
                    {FILL_COLORS.filter(c => c !== 'transparent').map(c => (
                      <button
                        key={c}
                        className={`color-swatch ${fillColor === c ? 'active' : ''}`}
                        style={{
                          background: c,
                          border: `2px solid ${fillColor === c ? '#4f6ef7' : 'var(--color-border)'}`,
                        }}
                        onClick={() => onFillColorChange(c)}
                      />
                    ))}
                    <input
                      type="color"
                      value={fillColor}
                      onChange={e => onFillColorChange(e.target.value)}
                      style={{ width: 22, height: 22, border: 'none', padding: 0, borderRadius: '50%', cursor: 'pointer' }}
                    />
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Options panel below */}
      {isDrawingTool && activeTool !== 'eraser' && (
        <div className="panel" style={{ padding: '8px 8px', width: 44 }}>
          {/* Stroke width */}
          <div className="tooltip" data-tip={`Width: ${strokeWidth}px`} style={{ width: 28, margin: '0 auto' }}>
            <input
              type="range"
              min={1}
              max={40}
              value={strokeWidth}
              onChange={e => onStrokeWidthChange(Number(e.target.value))}
              style={{
                width: 80,
                transform: 'rotate(-90deg) translateX(-18px) translateY(-18px)',
                height: 28,
                cursor: 'pointer',
                accentColor: '#4f6ef7',
              }}
            />
          </div>
          <div style={{
            textAlign: 'center',
            fontSize: 10,
            color: 'var(--color-muted)',
            marginTop: 28,
          }}>{strokeWidth}</div>

          {/* Dash options */}
          <div style={{ height: 1, background: 'var(--color-border)', margin: '6px 0' }} />
          {DASH_PRESETS.map(preset => (
            <button
              key={preset.label}
              className="btn-icon tooltip"
              data-tip={preset.label}
              onClick={() => onDashArrayChange(preset.value)}
              style={{
                width: 34,
                height: 20,
                borderRadius: 4,
                marginBottom: 2,
                background: JSON.stringify(dashArray) === JSON.stringify(preset.value)
                  ? 'color-mix(in srgb, #4f6ef7 15%, transparent)'
                  : 'transparent',
              }}
            >
              <svg width="20" height="4" style={{ overflow: 'visible' }}>
                <line
                  x1="0" y1="2" x2="20" y2="2"
                  stroke="var(--color-text)"
                  strokeWidth="1.5"
                  strokeDasharray={preset.value.join(',')}
                />
              </svg>
            </button>
          ))}
        </div>
      )}

      {/* Opacity */}
      {isDrawingTool && (
        <div className="panel" style={{ padding: '6px 8px', width: 44 }}>
          <div className="tooltip" data-tip={`Opacity: ${Math.round(opacity * 100)}%`} style={{ width: 28, margin: '0 auto' }}>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={opacity}
              onChange={e => onOpacityChange(Number(e.target.value))}
              style={{
                width: 70,
                transform: 'rotate(-90deg) translateX(-12px) translateY(-15px)',
                height: 28,
                cursor: 'pointer',
                accentColor: '#4f6ef7',
              }}
            />
          </div>
          <div style={{
            textAlign: 'center',
            fontSize: 10,
            color: 'var(--color-muted)',
            marginTop: 24,
          }}>{Math.round(opacity * 100)}%</div>
        </div>
      )}
    </div>
  );
}
