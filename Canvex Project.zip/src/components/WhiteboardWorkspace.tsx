import { useState, useEffect, useRef, useCallback } from 'react';
import {
  Layers, Layout, StickyNote, Search, Plus,
  ZoomIn, ZoomOut, RotateCcw, X, ChevronRight,
} from 'lucide-react';
import {
  BoardSession, BoardObject, saveSession,
  generateId,
} from '../utils/storage';
import {
  drawGrid, renderObject, hitTestObject,
  screenToCanvas, snapToGrid as snapVal,
  getBoundingBox,
} from '../utils/canvasEngine';
import Toolbar, { ToolType } from './Toolbar';
import WorkspaceHeader from './WorkspaceHeader';
import LayersPanel from './LayersPanel';
import PlanningPanel from './PlanningPanel';
import CommandPalette, { CommandItem } from './CommandPalette';

interface WhiteboardWorkspaceProps {
  session: BoardSession;
  darkMode: boolean;
  onReturnHome: (updatedSession: BoardSession) => void;
  onToggleDark: (dark: boolean) => void;
}

interface ViewState {
  offsetX: number;
  offsetY: number;
  zoom: number;
}

const MIN_ZOOM = 0.1;
const MAX_ZOOM = 8;
const AUTOSAVE_DELAY = 1500;

const STICKY_COLORS = ['#fef3c7', '#dbeafe', '#d1fae5', '#fce7f3', '#ede9fe', '#cffafe', '#fee2e2', '#f3f4f6'];

export default function WhiteboardWorkspace({
  session: initialSession,
  darkMode,
  onReturnHome,
  onToggleDark,
}: WhiteboardWorkspaceProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const animFrameRef = useRef<number>(0);
  const autosaveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const imagesRef = useRef<Map<string, HTMLImageElement>>(new Map());

  // Session state
  const [session, setSession] = useState<BoardSession>(initialSession);
  const sessionRef = useRef<BoardSession>(initialSession);

  // View state
  const [view, setView] = useState<ViewState>(initialSession.viewState);
  const viewRef = useRef<ViewState>(initialSession.viewState);

  // Tool state
  const [activeTool, setActiveTool] = useState<ToolType>('pen');
  const activeToolRef = useRef<ToolType>('pen');
  const [color, setColor] = useState('#1a1d23');
  const colorRef = useRef('#1a1d23');
  const [strokeWidth, setStrokeWidth] = useState(3);
  const strokeWidthRef = useRef(3);
  const [opacity, setOpacity] = useState(1);
  const opacityRef = useRef(1);
  const [fillColor, setFillColor] = useState('#dbeafe');
  const fillColorRef = useRef('#dbeafe');
  const [filled, setFilled] = useState(false);
  const filledRef = useRef(false);
  const [dashArray, setDashArray] = useState<number[]>([]);
  const dashArrayRef = useRef<number[]>([]);

  // Objects & history
  const [objects, setObjects] = useState<BoardObject[]>(initialSession.objects);
  const objectsRef = useRef<BoardObject[]>(initialSession.objects);
  const [history, setHistory] = useState<BoardObject[][]>([initialSession.objects]);
  const historyRef = useRef<BoardObject[][]>([initialSession.objects]);
  const historyIndexRef = useRef(0);

  // Selection
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const selectedIdsRef = useRef<Set<string>>(new Set());

  // Drawing state
  const isDrawingRef = useRef(false);
  const currentStrokeRef = useRef<number[]>([]);
  const currentObjIdRef = useRef<string>('');
  const drawStartRef = useRef<{ x: number; y: number } | null>(null);
  const isPanningRef = useRef(false);
  const panStartRef = useRef<{ x: number; y: number; ox: number; oy: number } | null>(null);
  const isDraggingRef = useRef(false);
  const dragStartRef = useRef<{ x: number; y: number } | null>(null);
  const dragObjectsStartRef = useRef<Map<string, { x: number; y: number }>>(new Map());

  const isArrowDrawingRef = useRef(false);
  const arrowStartRef = useRef<{ x: number; y: number } | null>(null);
  const lastPointerPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const lassoPointsRef = useRef<number[]>([]);
  const isLassoRef = useRef(false);
  const spaceDownRef = useRef(false);
  const isTouchPanRef = useRef(false);
  const lastTouchDistRef = useRef(0);
  const lastTouchMidRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // UI state
  const [showLayers, setShowLayers] = useState(false);
  const [showPlanning, setShowPlanning] = useState(false);
  const [showCommandPalette, setShowCommandPalette] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'unsaved'>('saved');
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; objectId?: string } | null>(null);
  const [textEditingId, setTextEditingId] = useState<string | null>(null);
  const [textEditValue, setTextEditValue] = useState('');
  const [canvasSize, setCanvasSize] = useState({ w: 800, h: 600 });

  // Sync refs with state
  useEffect(() => { sessionRef.current = session; }, [session]);
  useEffect(() => { viewRef.current = view; }, [view]);
  useEffect(() => { objectsRef.current = objects; }, [objects]);
  useEffect(() => { activeToolRef.current = activeTool; }, [activeTool]);
  useEffect(() => { colorRef.current = color; }, [color]);
  useEffect(() => { strokeWidthRef.current = strokeWidth; }, [strokeWidth]);
  useEffect(() => { opacityRef.current = opacity; }, [opacity]);
  useEffect(() => { fillColorRef.current = fillColor; }, [fillColor]);
  useEffect(() => { filledRef.current = filled; }, [filled]);
  useEffect(() => { dashArrayRef.current = dashArray; }, [dashArray]);
  useEffect(() => { selectedIdsRef.current = selectedIds; }, [selectedIds]);

  // Canvas resize
  useEffect(() => {
    const updateSize = () => {
      if (containerRef.current) {
        setCanvasSize({
          w: containerRef.current.clientWidth,
          h: containerRef.current.clientHeight,
        });
      }
    };
    updateSize();
    const ro = new ResizeObserver(updateSize);
    if (containerRef.current) ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, []);

  // Main render loop
  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { offsetX, offsetY, zoom } = viewRef.current;
    const w = canvas.width;
    const h = canvas.height;

    // Background
    ctx.fillStyle = darkMode ? '#111318' : '#f8f9fb';
    ctx.fillRect(0, 0, w, h);

    // Grid
    const sess = sessionRef.current;
    drawGrid(ctx, w, h, sess.settings.gridMode, sess.settings.gridSize, offsetX, offsetY, zoom, darkMode);

    // Objects
    ctx.save();
    ctx.translate(offsetX, offsetY);
    ctx.scale(zoom, zoom);

    // Sort by layer order
    const layerOrder = sess.layers.map(l => l.id);
    const sorted = [...objectsRef.current].sort((a, b) => {
      const ai = layerOrder.indexOf(a.layerId);
      const bi = layerOrder.indexOf(b.layerId);
      return ai - bi;
    });

    for (const obj of sorted) {
      // Check layer visibility
      const layer = sess.layers.find(l => l.id === obj.layerId);
      if (layer && !layer.visible) continue;

      ctx.save();
      if (layer && layer.opacity < 1) {
        ctx.globalAlpha = layer.opacity;
      }

      if (obj.type === 'image') {
        const img = imagesRef.current.get(obj.id);
        if (img) {
          ctx.globalAlpha = (layer?.opacity ?? 1) * (obj.opacity ?? 1);
          ctx.drawImage(img, obj.x, obj.y, obj.width || img.naturalWidth, obj.height || img.naturalHeight);
        }
      } else {
        renderObject(ctx, obj, selectedIdsRef.current.has(obj.id));
      }
      ctx.restore();
    }

    // Current stroke being drawn
    if (isDrawingRef.current && currentStrokeRef.current.length > 2) {
      ctx.beginPath();
      ctx.strokeStyle = colorRef.current;
      ctx.lineWidth = strokeWidthRef.current;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.globalAlpha = opacityRef.current;
      const pts = currentStrokeRef.current;
      ctx.moveTo(pts[0], pts[1]);
      for (let i = 2; i < pts.length - 2; i += 2) {
        const mx = (pts[i] + pts[i + 2]) / 2;
        const my = (pts[i + 1] + pts[i + 3]) / 2;
        ctx.quadraticCurveTo(pts[i], pts[i + 1], mx, my);
      }
      ctx.lineTo(pts[pts.length - 2], pts[pts.length - 1]);
      if (dashArrayRef.current.length > 0) ctx.setLineDash(dashArrayRef.current);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;
    }

    // Arrow being drawn
    if (isArrowDrawingRef.current && arrowStartRef.current) {
      const { x: ax, y: ay } = arrowStartRef.current;
      const { x: bx, y: by } = lastPointerPosRef.current;
      ctx.beginPath();
      ctx.strokeStyle = colorRef.current;
      ctx.lineWidth = strokeWidthRef.current;
      ctx.lineCap = 'round';
      ctx.globalAlpha = opacityRef.current;
      ctx.moveTo(ax, ay);
      ctx.lineTo(bx, by);
      const angle = Math.atan2(by - ay, bx - ax);
      const hl = 14;
      ctx.moveTo(bx, by);
      ctx.lineTo(bx - hl * Math.cos(angle - Math.PI / 6), by - hl * Math.sin(angle - Math.PI / 6));
      ctx.moveTo(bx, by);
      ctx.lineTo(bx - hl * Math.cos(angle + Math.PI / 6), by - hl * Math.sin(angle + Math.PI / 6));
      ctx.stroke();
      ctx.globalAlpha = 1;
    }

    // Shape preview
    if (isDrawingRef.current && drawStartRef.current && ['rect', 'ellipse', 'triangle', 'diamond', 'hexagon', 'star', 'line'].includes(activeToolRef.current)) {
      const { x: sx, y: sy } = drawStartRef.current;
      const { x: ex, y: ey } = lastPointerPosRef.current;
      const w2 = ex - sx, h2 = ey - sy;
      ctx.strokeStyle = colorRef.current;
      ctx.lineWidth = strokeWidthRef.current;
      ctx.setLineDash(dashArrayRef.current.length > 0 ? dashArrayRef.current : [6, 3]);
      ctx.globalAlpha = opacityRef.current;
      ctx.beginPath();
      if (activeToolRef.current === 'ellipse') {
        ctx.ellipse(sx + w2 / 2, sy + h2 / 2, Math.abs(w2) / 2, Math.abs(h2) / 2, 0, 0, Math.PI * 2);
      } else if (activeToolRef.current === 'line') {
        ctx.moveTo(sx, sy);
        ctx.lineTo(ex, ey);
      } else {
        ctx.rect(sx, sy, w2, h2);
      }
      if (filledRef.current && fillColorRef.current) {
        ctx.fillStyle = fillColorRef.current;
        ctx.fill();
      }
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;
    }

    // Lasso selection
    if (isLassoRef.current && lassoPointsRef.current.length > 4) {
      ctx.beginPath();
      ctx.strokeStyle = '#4f6ef7';
      ctx.lineWidth = 1 / zoom;
      ctx.setLineDash([4 / zoom, 3 / zoom]);
      ctx.globalAlpha = 0.6;
      const lpts = lassoPointsRef.current;
      ctx.moveTo(lpts[0], lpts[1]);
      for (let i = 2; i < lpts.length; i += 2) ctx.lineTo(lpts[i], lpts[i + 1]);
      ctx.closePath();
      ctx.fillStyle = 'rgba(79,110,247,0.08)';
      ctx.fill();
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;
    }

    ctx.restore();

    // Minimap
    renderMinimap(ctx, w, h, sorted);
  }, [darkMode]);

  const renderMinimap = (ctx: CanvasRenderingContext2D, cw: number, ch: number, objs: BoardObject[]) => {
    const mw = 150, mh = 94;
    const mx = cw - mw - 12, my = ch - mh - 36;

    ctx.save();
    ctx.fillStyle = darkMode ? '#1c1f27' : '#ffffff';
    ctx.strokeStyle = darkMode ? '#2a2d38' : '#e2e6ed';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect(mx, my, mw, mh, 6);
    ctx.fill();
    ctx.stroke();

    // Viewport indicator
    const { offsetX, offsetY, zoom } = viewRef.current;
    const worldScale = 0.04;
    const vpX = mx + mw / 2 - (-offsetX / zoom) * worldScale;
    const vpY = my + mh / 2 - (-offsetY / zoom) * worldScale;
    const vpW = (cw / zoom) * worldScale;
    const vpH = (ch / zoom) * worldScale;

    ctx.fillStyle = 'rgba(79,110,247,0.12)';
    ctx.strokeStyle = '#4f6ef7';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.rect(vpX, vpY, vpW, vpH);
    ctx.fill();
    ctx.stroke();

    // Dots for objects
    objs.slice(0, 40).forEach(obj => {
      const bx = mx + mw / 2 + (obj.x - (-offsetX / zoom)) * worldScale;
      const by = my + mh / 2 + (obj.y - (-offsetY / zoom)) * worldScale;
      if (bx > mx && bx < mx + mw && by > my && by < my + mh) {
        ctx.fillStyle = obj.color || '#4f6ef7';
        ctx.globalAlpha = 0.5;
        ctx.beginPath();
        ctx.arc(bx, by, 2, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
      }
    });

    ctx.restore();
  };

  // Schedule render
  const scheduleRender = useCallback(() => {
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    animFrameRef.current = requestAnimationFrame(render);
  }, [render]);

  useEffect(() => {
    scheduleRender();
  }, [scheduleRender, objects, view, darkMode, selectedIds]);

  // Autosave
  const triggerAutosave = useCallback(() => {
    setSaveStatus('unsaved');
    if (autosaveTimerRef.current) clearTimeout(autosaveTimerRef.current);
    autosaveTimerRef.current = setTimeout(async () => {
      setSaveStatus('saving');
      const currentSession = sessionRef.current;
      const thumbnail = generateThumbnail();
      const toSave: BoardSession = {
        ...currentSession,
        objects: objectsRef.current,
        viewState: viewRef.current,
        updatedAt: Date.now(),
        thumbnail,
      };
      try {
        await saveSession(toSave);
        setSession(toSave);
        setSaveStatus('saved');
      } catch (err) {
        console.error('Autosave failed:', err);
        setSaveStatus('unsaved');
      }
    }, AUTOSAVE_DELAY);
  }, []);

  const generateThumbnail = (): string => {
    const canvas = canvasRef.current;
    if (!canvas) return '';
    try {
      return canvas.toDataURL('image/jpeg', 0.4);
    } catch {
      return '';
    }
  };

  // Update objects
  const updateObjects = useCallback((newObjs: BoardObject[], pushHistory = true) => {
    objectsRef.current = newObjs;
    setObjects(newObjs);
    if (pushHistory) {
      const idx = historyIndexRef.current;
      const newHistory = historyRef.current.slice(0, idx + 1);
      newHistory.push(newObjs);
      if (newHistory.length > 60) newHistory.shift();
      historyRef.current = newHistory;
      historyIndexRef.current = newHistory.length - 1;
      setHistory(newHistory);
    }
    triggerAutosave();
    scheduleRender();
  }, [triggerAutosave, scheduleRender]);

  const undo = useCallback(() => {
    if (historyIndexRef.current <= 0) return;
    historyIndexRef.current--;
    const prev = historyRef.current[historyIndexRef.current];
    objectsRef.current = prev;
    setObjects(prev);
    scheduleRender();
    triggerAutosave();
  }, [scheduleRender, triggerAutosave]);

  const redo = useCallback(() => {
    if (historyIndexRef.current >= historyRef.current.length - 1) return;
    historyIndexRef.current++;
    const next = historyRef.current[historyIndexRef.current];
    objectsRef.current = next;
    setObjects(next);
    scheduleRender();
    triggerAutosave();
  }, [scheduleRender, triggerAutosave]);

  // Delete selected
  const deleteSelected = useCallback(() => {
    if (selectedIdsRef.current.size === 0) return;
    const newObjs = objectsRef.current.filter(o => !selectedIdsRef.current.has(o.id));
    setSelectedIds(new Set());
    updateObjects(newObjs);
  }, [updateObjects]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if in input
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      const ctrl = e.ctrlKey || e.metaKey;

      if (ctrl && e.key === 'z') { e.preventDefault(); undo(); return; }
      if (ctrl && (e.key === 'y' || e.key === 'Z')) { e.preventDefault(); redo(); return; }
      if (ctrl && e.key === 'k') { e.preventDefault(); setShowCommandPalette(s => !s); return; }
      if (ctrl && e.key === 'a') {
        e.preventDefault();
        setSelectedIds(new Set(objectsRef.current.map(o => o.id)));
        return;
      }
      if (ctrl && e.key === 'c') { copySelected(); return; }
      if (ctrl && e.key === 'v') { pasteObjects(); return; }
      if (ctrl && e.key === 'd') { e.preventDefault(); duplicateSelected(); return; }
      if (e.key === 'Delete' || e.key === 'Backspace') { deleteSelected(); return; }
      if (e.key === 'Escape') {
        setSelectedIds(new Set());
        setShowCommandPalette(false);
        setContextMenu(null);
        setTextEditingId(null);
        return;
      }

      if (e.key === ' ') { spaceDownRef.current = true; return; }

      // Tool shortcuts
      const toolMap: Record<string, ToolType> = {
        'v': 'select', 'p': 'pen', 'n': 'pencil',
        'm': 'marker', 'e': 'eraser', 'r': 'rect',
        'o': 'ellipse', 'a': 'arrow', 't': 'text',
        's': 'sticky', 'l': 'lasso', 'i': 'eyedropper',
      };
      if (!ctrl && toolMap[e.key.toLowerCase()]) {
        setActiveTool(toolMap[e.key.toLowerCase()]);
        activeToolRef.current = toolMap[e.key.toLowerCase()];
        return;
      }

      // Zoom
      if (ctrl && e.key === '=') { e.preventDefault(); zoomAt(0.5, 0.5, 0.2); }
      if (ctrl && e.key === '-') { e.preventDefault(); zoomAt(0.5, 0.5, -0.2); }
      if (ctrl && e.key === '0') { e.preventDefault(); setView({ offsetX: 0, offsetY: 0, zoom: 1 }); viewRef.current = { offsetX: 0, offsetY: 0, zoom: 1 }; }

      // Move selected with arrow keys
      if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key) && selectedIdsRef.current.size > 0) {
        e.preventDefault();
        const delta = e.shiftKey ? 10 : 1;
        const dx = e.key === 'ArrowLeft' ? -delta : e.key === 'ArrowRight' ? delta : 0;
        const dy = e.key === 'ArrowUp' ? -delta : e.key === 'ArrowDown' ? delta : 0;
        const newObjs = objectsRef.current.map(o => {
          if (!selectedIdsRef.current.has(o.id)) return o;
          if (o.type === 'arrow') {
            return { ...o, x: o.x + dx, y: o.y + dy, x2: (o.x2 ?? 0) + dx, y2: (o.y2 ?? 0) + dy };
          }
          return { ...o, x: o.x + dx, y: o.y + dy };
        });
        updateObjects(newObjs);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === ' ') spaceDownRef.current = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [undo, redo, deleteSelected]);

  // Clipboard
  const clipboardRef = useRef<BoardObject[]>([]);

  const copySelected = useCallback(() => {
    const selected = objectsRef.current.filter(o => selectedIdsRef.current.has(o.id));
    clipboardRef.current = selected.map(o => ({ ...o }));
  }, []);

  const pasteObjects = useCallback(() => {
    if (!clipboardRef.current.length) return;
    const now = Date.now();
    const pasted = clipboardRef.current.map(o => ({
      ...o,
      id: `${o.id}-copy-${now}`,
      x: o.x + 20,
      y: o.y + 20,
      layerId: sessionRef.current.activeLayerId,
    }));
    updateObjects([...objectsRef.current, ...pasted]);
    setSelectedIds(new Set(pasted.map(o => o.id)));
    clipboardRef.current = pasted.map(o => ({ ...o }));
  }, [updateObjects]);

  const duplicateSelected = useCallback(() => {
    copySelected();
    pasteObjects();
  }, [copySelected, pasteObjects]);

  // Zoom helpers
  const zoomAt = useCallback((normalizedX: number, normalizedY: number, delta: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const screenX = normalizedX * canvas.width;
    const screenY = normalizedY * canvas.height;
    const { offsetX, offsetY, zoom } = viewRef.current;
    const newZoom = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, zoom + delta * zoom));
    const ratio = newZoom / zoom;
    const newOffsetX = screenX - ratio * (screenX - offsetX);
    const newOffsetY = screenY - ratio * (screenY - offsetY);
    const newView = { offsetX: newOffsetX, offsetY: newOffsetY, zoom: newZoom };
    viewRef.current = newView;
    setView(newView);
    scheduleRender();
  }, [scheduleRender]);

  const zoomAtPoint = useCallback((sx: number, sy: number, delta: number) => {
    const { offsetX, offsetY, zoom } = viewRef.current;
    const newZoom = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, zoom * (1 + delta)));
    const ratio = newZoom / zoom;
    const newOffsetX = sx - ratio * (sx - offsetX);
    const newOffsetY = sy - ratio * (sy - offsetY);
    const newView = { offsetX: newOffsetX, offsetY: newOffsetY, zoom: newZoom };
    viewRef.current = newView;
    setView(newView);
    scheduleRender();
  }, [scheduleRender]);

  // Get canvas-space coordinates from screen event
  const eventToCanvas = (e: PointerEvent | WheelEvent | MouseEvent) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const sx = (e as MouseEvent).clientX - rect.left;
    const sy = (e as MouseEvent).clientY - rect.top;
    return screenToCanvas(sx, sy, viewRef.current.offsetX, viewRef.current.offsetY, viewRef.current.zoom);
  };

  const getScreenPos = (e: PointerEvent | MouseEvent) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: (e as MouseEvent).clientX - rect.left,
      y: (e as MouseEvent).clientY - rect.top,
    };
  };

  // Context menu
  const handleContextMenu = useCallback((e: MouseEvent) => {
    e.preventDefault();
    const { x, y } = getScreenPos(e as PointerEvent);
    const canvasPos = eventToCanvas(e);
    const hit = objectsRef.current.find(o => hitTestObject(o, canvasPos.x, canvasPos.y));
    setContextMenu({ x, y, objectId: hit?.id });
    setShowCommandPalette(false);
  }, []);

  // Pointer events
  const handlePointerDown = useCallback((e: PointerEvent) => {
    if (e.button === 2) return; // Right click handled by contextmenu
    setContextMenu(null);

    const canvas = canvasRef.current!;
    canvas.setPointerCapture(e.pointerId);

    const sp = getScreenPos(e);
    const cp = eventToCanvas(e);

    // Palm rejection: ignore large touch areas
    if (e.pointerType === 'touch' && e.width > 50) return;

    // Space+drag = pan
    if (spaceDownRef.current || activeToolRef.current === 'pan' || e.button === 1) {
      isPanningRef.current = true;
      panStartRef.current = { x: sp.x, y: sp.y, ox: viewRef.current.offsetX, oy: viewRef.current.offsetY };
      return;
    }

    const tool = activeToolRef.current;
    const sess = sessionRef.current;

    // Check if active layer is locked
    const activeLayer = sess.layers.find(l => l.id === sess.activeLayerId);
    if (activeLayer?.locked && tool !== 'select' && tool !== 'pan' && tool !== 'lasso') {
      return;
    }

    const snap = sess.settings.snapToGrid;
    const snapX = snap ? snapVal(cp.x, sess.settings.gridSize) : cp.x;
    const snapY = snap ? snapVal(cp.y, sess.settings.gridSize) : cp.y;

    if (tool === 'select') {
      // Check for object hit
      const hit = [...objectsRef.current].reverse().find(o => hitTestObject(o, cp.x, cp.y));
      if (hit) {
        if (!e.shiftKey && !selectedIdsRef.current.has(hit.id)) {
          setSelectedIds(new Set([hit.id]));
          selectedIdsRef.current = new Set([hit.id]);
        } else if (e.shiftKey) {
          const newSel = new Set(selectedIdsRef.current);
          if (newSel.has(hit.id)) newSel.delete(hit.id);
          else newSel.add(hit.id);
          setSelectedIds(newSel);
          selectedIdsRef.current = newSel;
        }

        // Start drag
        isDraggingRef.current = true;
        dragStartRef.current = cp;
        dragObjectsStartRef.current = new Map(
          objectsRef.current
            .filter(o => selectedIdsRef.current.has(o.id))
            .map(o => [o.id, { x: o.x, y: o.y }])
        );
      } else {
        // Start lasso from select mode
        setSelectedIds(new Set());
        selectedIdsRef.current = new Set();
        isLassoRef.current = true;
        lassoPointsRef.current = [cp.x, cp.y];
      }
    } else if (tool === 'lasso') {
      isLassoRef.current = true;
      lassoPointsRef.current = [cp.x, cp.y];
    } else if (tool === 'eraser') {
      isDrawingRef.current = true;
      currentStrokeRef.current = [cp.x, cp.y];
    } else if (tool === 'text') {
      // Place text
      const id = generateId();
      const obj: BoardObject = {
        id,
        type: 'text',
        x: snapX,
        y: snapY,
        width: 300,
        height: 40,
        layerId: sess.activeLayerId,
        visible: true,
        locked: false,
        opacity: opacityRef.current,
        text: '',
        fontSize: 18,
        fontFamily: 'Inter, sans-serif',
        fontWeight: 'normal',
        color: colorRef.current,
      };
      updateObjects([...objectsRef.current, obj]);
      setTextEditingId(id);
      setTextEditValue('');
    } else if (tool === 'sticky') {
      const id = generateId();
      const noteColor = STICKY_COLORS[Math.floor(Math.random() * STICKY_COLORS.length)];
      const obj: BoardObject = {
        id,
        type: 'sticky',
        x: snapX,
        y: snapY,
        width: 180,
        height: 120,
        layerId: sess.activeLayerId,
        visible: true,
        locked: false,
        opacity: 1,
        text: '',
        noteColor,
        fontSize: 13,
      };
      updateObjects([...objectsRef.current, obj]);
      setTextEditingId(id);
      setTextEditValue('');
    } else if (tool === 'arrow') {
      isArrowDrawingRef.current = true;
      arrowStartRef.current = { x: snapX, y: snapY };
      lastPointerPosRef.current = { x: snapX, y: snapY };
    } else if (['pen', 'pencil', 'marker', 'brush'].includes(tool)) {
      isDrawingRef.current = true;
      // pressure used for future pressure-sensitive width
      const _pressure = (e as any).pressure || 1; void _pressure;
      currentStrokeRef.current = [cp.x, cp.y];
      currentObjIdRef.current = generateId();
    } else if (['rect', 'ellipse', 'triangle', 'diamond', 'hexagon', 'star', 'line'].includes(tool)) {
      isDrawingRef.current = true;
      drawStartRef.current = { x: snapX, y: snapY };
      lastPointerPosRef.current = { x: snapX, y: snapY };
    } else if (tool === 'eyedropper') {
      // Pick color from canvas pixel
      const imgData = canvasRef.current?.getContext('2d')?.getImageData(sp.x, sp.y, 1, 1);
      if (imgData) {
        const [r, g, b] = imgData.data;
        const hex = `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
        setColor(hex);
        colorRef.current = hex;
        setActiveTool('pen');
        activeToolRef.current = 'pen';
      }
    }
  }, [updateObjects]);

  const handlePointerMove = useCallback((e: PointerEvent) => {
    const sp = getScreenPos(e);
    const cp = eventToCanvas(e);
    const sess = sessionRef.current;
    const snap = sess.settings.snapToGrid;
    const snapX = snap ? snapVal(cp.x, sess.settings.gridSize) : cp.x;
    const snapY = snap ? snapVal(cp.y, sess.settings.gridSize) : cp.y;

    lastPointerPosRef.current = { x: snapX, y: snapY };

    if (isPanningRef.current && panStartRef.current) {
      const { x: sx, y: sy, ox, oy } = panStartRef.current;
      const newOffX = ox + (sp.x - sx);
      const newOffY = oy + (sp.y - sy);
      viewRef.current = { ...viewRef.current, offsetX: newOffX, offsetY: newOffY };
      setView(v => ({ ...v, offsetX: newOffX, offsetY: newOffY }));
      scheduleRender();
      return;
    }

    if (isDraggingRef.current && dragStartRef.current) {
      const dx = cp.x - dragStartRef.current.x;
      const dy = cp.y - dragStartRef.current.y;
      const newObjs = objectsRef.current.map(o => {
        if (!selectedIdsRef.current.has(o.id)) return o;
        const start = dragObjectsStartRef.current.get(o.id);
        if (!start) return o;
        let nx = start.x + dx;
        let ny = start.y + dy;
        if (snap) {
          nx = snapVal(nx, sess.settings.gridSize);
          ny = snapVal(ny, sess.settings.gridSize);
        }
        if (o.type === 'arrow') {
          const dx2 = (o.x2 ?? o.x) - o.x;
          const dy2 = (o.y2 ?? o.y) - o.y;
          return { ...o, x: nx, y: ny, x2: nx + dx2, y2: ny + dy2 };
        }
        return { ...o, x: nx, y: ny };
      });
      objectsRef.current = newObjs;
      setObjects(newObjs);
      scheduleRender();
      return;
    }

    if (isLassoRef.current) {
      lassoPointsRef.current = [...lassoPointsRef.current, cp.x, cp.y];
      scheduleRender();
      return;
    }

    const tool = activeToolRef.current;

    if (isDrawingRef.current) {
      if (tool === 'eraser') {
        // Erase objects under pointer
        const eraseRadius = strokeWidthRef.current * 2;
        const toRemove = objectsRef.current.filter(o => {
          const bb = getBoundingBox(o);
          return cp.x >= bb.x - eraseRadius && cp.x <= bb.x + bb.w + eraseRadius &&
            cp.y >= bb.y - eraseRadius && cp.y <= bb.y + bb.h + eraseRadius;
        });
        if (toRemove.length > 0) {
          const ids = new Set(toRemove.map(o => o.id));
          objectsRef.current = objectsRef.current.filter(o => !ids.has(o.id));
          setObjects([...objectsRef.current]);
        }
      } else if (['pen', 'pencil', 'marker', 'brush'].includes(tool)) {
        currentStrokeRef.current = [...currentStrokeRef.current, cp.x, cp.y];
      }
      scheduleRender();
    }

    if (isArrowDrawingRef.current) {
      scheduleRender();
    }
  }, [scheduleRender]);

  const handlePointerUp = useCallback((e: PointerEvent) => {
    const cp = eventToCanvas(e);
    const sess = sessionRef.current;
    const snap = sess.settings.snapToGrid;
    const snapX = snap ? snapVal(cp.x, sess.settings.gridSize) : cp.x;
    const snapY = snap ? snapVal(cp.y, sess.settings.gridSize) : cp.y;

    if (isPanningRef.current) {
      isPanningRef.current = false;
      panStartRef.current = null;
      triggerAutosave();
      return;
    }

    if (isDraggingRef.current) {
      isDraggingRef.current = false;
      dragStartRef.current = null;
      updateObjects(objectsRef.current);
      return;
    }

    if (isLassoRef.current) {
      isLassoRef.current = false;
      // Find objects inside lasso
      const pts = lassoPointsRef.current;
      if (pts.length > 4) {
        const inside = objectsRef.current.filter(o => {
          const bb = getBoundingBox(o);
          const cx = bb.x + bb.w / 2, cy = bb.y + bb.h / 2;
          return pointInPolygon(cx, cy, pts);
        });
        setSelectedIds(new Set(inside.map(o => o.id)));
        selectedIdsRef.current = new Set(inside.map(o => o.id));
      }
      lassoPointsRef.current = [];
      scheduleRender();
      return;
    }

    const tool = activeToolRef.current;

    if (isDrawingRef.current) {
      isDrawingRef.current = false;

      if (tool === 'eraser') {
        updateObjects(objectsRef.current);
        currentStrokeRef.current = [];
        return;
      }

      if (['pen', 'pencil', 'marker', 'brush'].includes(tool)) {
        const pts = currentStrokeRef.current;
        if (pts.length >= 2) {
          const obj: BoardObject = {
            id: currentObjIdRef.current || generateId(),
            type: 'stroke',
            x: 0, y: 0,
            layerId: sess.activeLayerId,
            visible: true,
            locked: false,
            points: [...pts],
            color: colorRef.current,
            strokeWidth: tool === 'marker' ? strokeWidthRef.current * 2 :
              tool === 'pencil' ? strokeWidthRef.current * 0.7 : strokeWidthRef.current,
            opacity: opacityRef.current,
            tool,
            dashArray: dashArrayRef.current,
          };
          updateObjects([...objectsRef.current, obj]);
        }
        currentStrokeRef.current = [];
        currentObjIdRef.current = '';
        return;
      }

      if (['rect', 'ellipse', 'triangle', 'diamond', 'hexagon', 'star', 'line'].includes(tool)) {
        const start = drawStartRef.current;
        if (!start) return;
        let x = Math.min(start.x, snapX);
        let y = Math.min(start.y, snapY);
        let w = Math.abs(snapX - start.x);
        let h = Math.abs(snapY - start.y);

        if (w < 4 && h < 4) {
          w = 100; h = tool === 'line' ? 0 : 60;
        }

        const obj: BoardObject = {
          id: generateId(),
          type: 'shape',
          shapeType: tool as any,
          x, y, width: w, height: h,
          layerId: sess.activeLayerId,
          visible: true,
          locked: false,
          color: colorRef.current,
          strokeWidth: strokeWidthRef.current,
          opacity: opacityRef.current,
          fillColor: fillColorRef.current,
          filled: filledRef.current,
          dashArray: dashArrayRef.current,
        };
        updateObjects([...objectsRef.current, obj]);
        setSelectedIds(new Set([obj.id]));
        drawStartRef.current = null;
        return;
      }
    }

    if (isArrowDrawingRef.current) {
      isArrowDrawingRef.current = false;
      const start = arrowStartRef.current;
      if (!start) return;
      const dx = snapX - start.x, dy = snapY - start.y;
      if (Math.sqrt(dx * dx + dy * dy) > 10) {
        const obj: BoardObject = {
          id: generateId(),
          type: 'arrow',
          x: start.x,
          y: start.y,
          x2: snapX,
          y2: snapY,
          layerId: sess.activeLayerId,
          visible: true,
          locked: false,
          color: colorRef.current,
          strokeWidth: strokeWidthRef.current,
          opacity: opacityRef.current,
          dashArray: dashArrayRef.current,
          endArrow: true,
          startArrow: false,
        };
        updateObjects([...objectsRef.current, obj]);
        setSelectedIds(new Set([obj.id]));
      }
      arrowStartRef.current = null;
    }
  }, [scheduleRender, triggerAutosave, updateObjects]);

  // Wheel zoom
  const handleWheel = useCallback((e: WheelEvent) => {
    e.preventDefault();
    const sp = getScreenPos(e as unknown as MouseEvent);
    const delta = -e.deltaY * 0.001;
    const scaledDelta = e.ctrlKey ? delta * 3 : delta;
    zoomAtPoint(sp.x, sp.y, scaledDelta);
  }, [zoomAtPoint]);

  // Touch events
  const handleTouchStart = useCallback((e: TouchEvent) => {
    if (e.touches.length === 2) {
      e.preventDefault();
      isTouchPanRef.current = true;
      const t1 = e.touches[0], t2 = e.touches[1];
      lastTouchDistRef.current = Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY);
      lastTouchMidRef.current = {
        x: (t1.clientX + t2.clientX) / 2,
        y: (t1.clientY + t2.clientY) / 2,
      };
    }
  }, []);

  const handleTouchMove = useCallback((e: TouchEvent) => {
    if (e.touches.length === 2 && isTouchPanRef.current) {
      e.preventDefault();
      const t1 = e.touches[0], t2 = e.touches[1];
      const dist = Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY);
      const mid = {
        x: (t1.clientX + t2.clientX) / 2,
        y: (t1.clientY + t2.clientY) / 2,
      };
      const canvas = canvasRef.current!;
      const rect = canvas.getBoundingClientRect();
      const sx = mid.x - rect.left, sy = mid.y - rect.top;

      // Pinch zoom
      const scale = dist / lastTouchDistRef.current;
      const zoomDelta = scale - 1;
      zoomAtPoint(sx, sy, zoomDelta * 0.8);

      // Pan
      const dx = mid.x - lastTouchMidRef.current.x;
      const dy = mid.y - lastTouchMidRef.current.y;
      viewRef.current = {
        ...viewRef.current,
        offsetX: viewRef.current.offsetX + dx,
        offsetY: viewRef.current.offsetY + dy,
      };
      setView({ ...viewRef.current });

      lastTouchDistRef.current = dist;
      lastTouchMidRef.current = mid;
      scheduleRender();
    }
  }, [zoomAtPoint, scheduleRender]);

  const handleTouchEnd = useCallback(() => {
    if (isTouchPanRef.current) {
      isTouchPanRef.current = false;
      triggerAutosave();
    }
  }, [triggerAutosave]);

  // Attach events
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    canvas.addEventListener('pointerdown', handlePointerDown, { passive: false });
    canvas.addEventListener('pointermove', handlePointerMove, { passive: false });
    canvas.addEventListener('pointerup', handlePointerUp, { passive: false });
    canvas.addEventListener('wheel', handleWheel, { passive: false });
    canvas.addEventListener('contextmenu', handleContextMenu);
    canvas.addEventListener('touchstart', handleTouchStart, { passive: false });
    canvas.addEventListener('touchmove', handleTouchMove, { passive: false });
    canvas.addEventListener('touchend', handleTouchEnd, { passive: false });

    return () => {
      canvas.removeEventListener('pointerdown', handlePointerDown);
      canvas.removeEventListener('pointermove', handlePointerMove);
      canvas.removeEventListener('pointerup', handlePointerUp);
      canvas.removeEventListener('wheel', handleWheel);
      canvas.removeEventListener('contextmenu', handleContextMenu);
      canvas.removeEventListener('touchstart', handleTouchStart);
      canvas.removeEventListener('touchmove', handleTouchMove);
      canvas.removeEventListener('touchend', handleTouchEnd);
    };
  }, [handlePointerDown, handlePointerMove, handlePointerUp, handleWheel, handleContextMenu, handleTouchStart, handleTouchMove, handleTouchEnd]);

  // Import image
  const handleImportImage = useCallback(() => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = () => {
      const file = input.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const src = ev.target?.result as string;
        const img = new Image();
        img.onload = () => {
          const id = generateId();
          const obj: BoardObject = {
            id,
            type: 'image',
            x: 100,
            y: 100,
            width: Math.min(img.naturalWidth, 600),
            height: Math.min(img.naturalHeight, 400),
            imageData: src,
            layerId: sessionRef.current.activeLayerId,
            visible: true,
            locked: false,
            opacity: 1,
          };
          imagesRef.current.set(id, img);
          updateObjects([...objectsRef.current, obj]);
        };
        img.src = src;
      };
      reader.readAsDataURL(file);
    };
    input.click();
  }, [updateObjects]);

  // Drag-drop file import
  useEffect(() => {
    const handleDrop = (e: DragEvent) => {
      e.preventDefault();
      const files = e.dataTransfer?.files;
      if (!files) return;
      for (const file of Array.from(files)) {
        if (file.type.startsWith('image/')) {
          const reader = new FileReader();
          reader.onload = (ev) => {
            const src = ev.target?.result as string;
            const img = new Image();
            img.onload = () => {
              const id = generateId();
              const canvas = canvasRef.current!;
              const rect = canvas.getBoundingClientRect();
              const cx = e.clientX - rect.left;
              const cy = e.clientY - rect.top;
              const cp = screenToCanvas(cx, cy, viewRef.current.offsetX, viewRef.current.offsetY, viewRef.current.zoom);
              const obj: BoardObject = {
                id,
                type: 'image',
                x: cp.x,
                y: cp.y,
                width: Math.min(img.naturalWidth, 600),
                height: Math.min(img.naturalHeight, 400),
                imageData: src,
                layerId: sessionRef.current.activeLayerId,
                visible: true,
                locked: false,
                opacity: 1,
              };
              imagesRef.current.set(id, img);
              updateObjects([...objectsRef.current, obj]);
            };
            img.src = src;
          };
          reader.readAsDataURL(file);
        } else if (file.name.endsWith('.canvex')) {
          // Load board file
          const reader = new FileReader();
          reader.onload = (ev) => {
            try {
              const data = JSON.parse(ev.target?.result as string) as BoardSession;
              setSession(data);
              setObjects(data.objects);
              objectsRef.current = data.objects;
              setView(data.viewState);
              viewRef.current = data.viewState;
              scheduleRender();
            } catch {}
          };
          reader.readAsText(file);
        }
      }
    };
    const handleDragOver = (e: DragEvent) => e.preventDefault();
    document.addEventListener('drop', handleDrop);
    document.addEventListener('dragover', handleDragOver);
    return () => {
      document.removeEventListener('drop', handleDrop);
      document.removeEventListener('dragover', handleDragOver);
    };
  }, [updateObjects, scheduleRender]);

  // Load existing image objects on mount
  useEffect(() => {
    initialSession.objects.forEach(obj => {
      if (obj.type === 'image' && obj.imageData) {
        const img = new Image();
        img.onload = () => {
          imagesRef.current.set(obj.id, img);
          scheduleRender();
        };
        img.src = obj.imageData;
      }
    });
  }, []);

  // Clipboard paste images
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;
      for (const item of Array.from(items)) {
        if (item.type.startsWith('image/')) {
          const blob = item.getAsFile();
          if (!blob) continue;
          const reader = new FileReader();
          reader.onload = (ev) => {
            const src = ev.target?.result as string;
            const img = new Image();
            img.onload = () => {
              const id = generateId();
              const obj: BoardObject = {
                id,
                type: 'image',
                x: 150,
                y: 150,
                width: Math.min(img.naturalWidth, 600),
                height: Math.min(img.naturalHeight, 400),
                imageData: src,
                layerId: sessionRef.current.activeLayerId,
                visible: true,
                locked: false,
                opacity: 1,
              };
              imagesRef.current.set(id, img);
              updateObjects([...objectsRef.current, obj]);
            };
            img.src = src;
          };
          reader.readAsDataURL(blob);
        }
      }
    };
    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [updateObjects]);

  // Export
  const handleExport = useCallback((format: 'png' | 'jpg' | 'svg' | 'pdf') => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    if (format === 'png' || format === 'jpg') {
      const link = document.createElement('a');
      link.download = `${session.name}.${format}`;
      link.href = canvas.toDataURL(format === 'jpg' ? 'image/jpeg' : 'image/png', 0.95);
      link.click();
    } else if (format === 'svg') {
      // Simple SVG export
      const svg = generateSVG();
      const blob = new Blob([svg], { type: 'image/svg+xml' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.download = `${session.name}.svg`;
      link.href = url;
      link.click();
      URL.revokeObjectURL(url);
    } else if (format === 'pdf') {
      // PDF via print
      const dataUrl = canvas.toDataURL('image/png');
      const w = window.open('', '_blank');
      if (w) {
        w.document.write(`
          <html><head><title>${session.name}</title>
          <style>body{margin:0;display:flex;justify-content:center;align-items:center;min-height:100vh;}
          img{max-width:100%;max-height:100vh;}</style></head>
          <body><img src="${dataUrl}" onload="window.print();window.close();" /></body></html>
        `);
      }
    }
  }, [session.name]);

  const generateSVG = (): string => {
    const canvas = canvasRef.current!;
    const w = canvas.width, h = canvas.height;
    let paths = '';
    for (const obj of objectsRef.current) {
      if (obj.type === 'stroke' && obj.points && obj.points.length > 2) {
        const { offsetX, offsetY, zoom } = viewRef.current;
        const pts = obj.points.map((p, i) => i % 2 === 0 ? p * zoom + offsetX : p * zoom + offsetY);
        let d = `M ${pts[0]} ${pts[1]}`;
        for (let i = 2; i < pts.length; i += 2) d += ` L ${pts[i]} ${pts[i + 1]}`;
        paths += `<path d="${d}" stroke="${obj.color || '#000'}" stroke-width="${(obj.strokeWidth || 2) * zoom}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
      }
    }
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">${paths}</svg>`;
  };

  // Save/Load board file
  const handleSaveBoard = useCallback(() => {
    const toSave: BoardSession = {
      ...sessionRef.current,
      objects: objectsRef.current,
      viewState: viewRef.current,
      updatedAt: Date.now(),
    };
    const blob = new Blob([JSON.stringify(toSave, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.download = `${session.name}.canvex`;
    link.href = url;
    link.click();
    URL.revokeObjectURL(url);
  }, [session.name]);

  const handleLoadBoard = useCallback(() => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.canvex,.json';
    input.onchange = () => {
      const file = input.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        try {
          const data = JSON.parse(ev.target?.result as string) as BoardSession;
          setSession(data);
          setObjects(data.objects);
          objectsRef.current = data.objects;
          setView(data.viewState);
          viewRef.current = data.viewState;
          scheduleRender();
        } catch {}
      };
      reader.readAsText(file);
    };
    input.click();
  }, [scheduleRender]);

  // Session updates
  const updateSession = useCallback((updates: Partial<BoardSession>) => {
    setSession(prev => {
      const updated = { ...prev, ...updates };
      sessionRef.current = updated;
      triggerAutosave();
      return updated;
    });
  }, [triggerAutosave]);

  const handleGridModeChange = (mode: 'none' | 'dots' | 'lines') => {
    updateSession({ settings: { ...session.settings, gridMode: mode } });
    scheduleRender();
  };

  const handleSnapToggle = () => {
    updateSession({ settings: { ...session.settings, snapToGrid: !session.settings.snapToGrid } });
  };

  const handleRenameBoard = (name: string) => {
    updateSession({ name });
  };

  const handleClearCanvas = () => {
    if (window.confirm('Clear all objects from canvas? This cannot be undone.')) {
      updateObjects([]);
      setSelectedIds(new Set());
    }
  };

  // Return home
  const handleReturnHome = useCallback(async () => {
    if (autosaveTimerRef.current) clearTimeout(autosaveTimerRef.current);
    const toSave: BoardSession = {
      ...sessionRef.current,
      objects: objectsRef.current,
      viewState: viewRef.current,
      updatedAt: Date.now(),
      thumbnail: generateThumbnail(),
    };
    await saveSession(toSave);
    onReturnHome(toSave);
  }, [onReturnHome]);

  // Search
  const searchResults = objects.filter(o => {
    if (!searchQuery) return false;
    const q = searchQuery.toLowerCase();
    return (o.text && o.text.toLowerCase().includes(q)) ||
      (o.title && o.title.toLowerCase().includes(q));
  });

  const focusObject = (obj: BoardObject) => {
    const canvas = canvasRef.current!;
    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    const targetZoom = 1.5;
    const newOffX = cx - obj.x * targetZoom;
    const newOffY = cy - obj.y * targetZoom;
    const newView = { offsetX: newOffX, offsetY: newOffY, zoom: targetZoom };
    viewRef.current = newView;
    setView(newView);
    setSelectedIds(new Set([obj.id]));
    scheduleRender();
    setShowSearch(false);
  };

  // Command palette commands
  const commands: CommandItem[] = [
    { id: 'undo', label: 'Undo', shortcut: 'Ctrl+Z', category: 'Edit', action: undo },
    { id: 'redo', label: 'Redo', shortcut: 'Ctrl+Y', category: 'Edit', action: redo },
    { id: 'select-all', label: 'Select All', shortcut: 'Ctrl+A', category: 'Edit', action: () => setSelectedIds(new Set(objects.map(o => o.id))) },
    { id: 'delete', label: 'Delete Selected', shortcut: 'Del', category: 'Edit', action: deleteSelected },
    { id: 'duplicate', label: 'Duplicate Selected', shortcut: 'Ctrl+D', category: 'Edit', action: duplicateSelected },
    { id: 'clear', label: 'Clear Canvas', category: 'Edit', action: handleClearCanvas },
    { id: 'zoom-in', label: 'Zoom In', shortcut: 'Ctrl++', category: 'View', action: () => zoomAt(0.5, 0.5, 0.3) },
    { id: 'zoom-out', label: 'Zoom Out', shortcut: 'Ctrl+-', category: 'View', action: () => zoomAt(0.5, 0.5, -0.3) },
    { id: 'zoom-reset', label: 'Reset Zoom', shortcut: 'Ctrl+0', category: 'View', action: () => { const nv = { offsetX: 0, offsetY: 0, zoom: 1 }; viewRef.current = nv; setView(nv); scheduleRender(); } },
    { id: 'grid-none', label: 'Grid: None', category: 'View', action: () => handleGridModeChange('none') },
    { id: 'grid-dots', label: 'Grid: Dots', category: 'View', action: () => handleGridModeChange('dots') },
    { id: 'grid-lines', label: 'Grid: Lines', category: 'View', action: () => handleGridModeChange('lines') },
    { id: 'dark', label: 'Toggle Dark Mode', category: 'View', action: () => onToggleDark(!darkMode) },
    { id: 'layers', label: 'Toggle Layers Panel', category: 'Panels', action: () => setShowLayers(s => !s) },
    { id: 'planning', label: 'Toggle Planning Panel', category: 'Panels', action: () => setShowPlanning(s => !s) },
    { id: 'tool-pen', label: 'Tool: Pen', shortcut: 'P', category: 'Tools', action: () => setActiveTool('pen') },
    { id: 'tool-select', label: 'Tool: Select', shortcut: 'V', category: 'Tools', action: () => setActiveTool('select') },
    { id: 'tool-eraser', label: 'Tool: Eraser', shortcut: 'E', category: 'Tools', action: () => setActiveTool('eraser') },
    { id: 'tool-text', label: 'Tool: Text', shortcut: 'T', category: 'Tools', action: () => setActiveTool('text') },
    { id: 'tool-sticky', label: 'Tool: Sticky Note', shortcut: 'S', category: 'Tools', action: () => setActiveTool('sticky') },
    { id: 'tool-arrow', label: 'Tool: Arrow', shortcut: 'A', category: 'Tools', action: () => setActiveTool('arrow') },
    { id: 'export-png', label: 'Export as PNG', category: 'File', action: () => handleExport('png') },
    { id: 'export-jpg', label: 'Export as JPG', category: 'File', action: () => handleExport('jpg') },
    { id: 'export-pdf', label: 'Export as PDF', category: 'File', action: () => handleExport('pdf') },
    { id: 'import-img', label: 'Import Image', category: 'File', action: handleImportImage },
    { id: 'save-file', label: 'Save Board to File', category: 'File', action: handleSaveBoard },
    { id: 'home', label: 'Return to Home', category: 'Navigation', action: handleReturnHome },
  ];

  // Cursor style
  const getCursor = () => {
    if (spaceDownRef.current || activeTool === 'pan') return isPanningRef.current ? 'grabbing' : 'grab';
    if (activeTool === 'select' || activeTool === 'lasso') return 'default';
    if (activeTool === 'eraser') return 'cell';
    if (activeTool === 'text') return 'text';
    if (activeTool === 'eyedropper') return 'crosshair';
    return 'crosshair';
  };

  const addObject = useCallback((obj: BoardObject) => {
    updateObjects([...objectsRef.current, obj]);
  }, [updateObjects]);

  const updateObjectById = useCallback((id: string, updates: Partial<BoardObject>) => {
    const newObjs = objectsRef.current.map(o => o.id === id ? { ...o, ...updates } : o);
    updateObjects(newObjs);
  }, [updateObjects]);

  const deleteObject = useCallback((id: string) => {
    const newObjs = objectsRef.current.filter(o => o.id !== id);
    setSelectedIds(prev => { const s = new Set(prev); s.delete(id); return s; });
    updateObjects(newObjs);
  }, [updateObjects]);

  const handleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.();
    } else {
      document.exitFullscreen?.();
    }
  };

  const handleDoubleClick = useCallback((e: React.MouseEvent) => {
    const cp = eventToCanvas(e.nativeEvent as MouseEvent);
    const hit = [...objectsRef.current].reverse().find(o =>
      (o.type === 'sticky' || o.type === 'text') && hitTestObject(o, cp.x, cp.y)
    );
    if (hit) {
      setTextEditingId(hit.id);
      setTextEditValue(hit.text || '');
    }
  }, []);

  return (
    <div className="workspace-page" style={{ background: 'var(--color-bg)' }}>
      {/* Header */}
      <WorkspaceHeader
        session={session}
        darkMode={darkMode}
        canUndo={historyIndexRef.current > 0}
        canRedo={historyIndexRef.current < history.length - 1}
        saveStatus={saveStatus}
        onUndo={undo}
        onRedo={redo}
        onReturnHome={handleReturnHome}
        onToggleDark={onToggleDark}
        onGridModeChange={handleGridModeChange}
        onSnapToggle={handleSnapToggle}
        onFullscreen={handleFullscreen}
        onExport={handleExport}
        onImportImage={handleImportImage}
        onSaveBoard={handleSaveBoard}
        onLoadBoard={handleLoadBoard}
        onNewBoard={() => {
          if (window.confirm('Start a new board? Current board is saved.')) {
            handleReturnHome();
          }
        }}
        onRenameBoard={handleRenameBoard}
        onClearCanvas={handleClearCanvas}
        onCommandPalette={() => setShowCommandPalette(s => !s)}
        zoomLevel={view.zoom}
        onZoomChange={z => { const nv = { ...viewRef.current, zoom: z }; viewRef.current = nv; setView(nv); scheduleRender(); }}
        onZoomReset={() => { const nv = { offsetX: 0, offsetY: 0, zoom: 1 }; viewRef.current = nv; setView(nv); scheduleRender(); }}
      />

      {/* Canvas area */}
      <div
        ref={containerRef}
        style={{
          position: 'absolute',
          top: 52,
          left: 0,
          right: 0,
          bottom: 28,
          overflow: 'hidden',
        }}
        onDoubleClick={handleDoubleClick}
      >
        <canvas
          ref={canvasRef}
          width={canvasSize.w}
          height={canvasSize.h}
          style={{ display: 'block', cursor: getCursor(), touchAction: 'none' }}
        />
      </div>

      {/* Left toolbar */}
      <div style={{ position: 'absolute', top: 52, bottom: 28, left: 0, display: 'flex', alignItems: 'center', pointerEvents: 'none' }}>
        <div style={{ pointerEvents: 'all' }}>
          <Toolbar
            activeTool={activeTool}
            onToolChange={t => { setActiveTool(t); activeToolRef.current = t; }}
            color={color}
            onColorChange={c => { setColor(c); colorRef.current = c; }}
            strokeWidth={strokeWidth}
            onStrokeWidthChange={w => { setStrokeWidth(w); strokeWidthRef.current = w; }}
            opacity={opacity}
            onOpacityChange={o => { setOpacity(o); opacityRef.current = o; }}
            fillColor={fillColor}
            onFillColorChange={c => { setFillColor(c); fillColorRef.current = c; }}
            filled={filled}
            onFilledChange={f => { setFilled(f); filledRef.current = f; }}
            dashArray={dashArray}
            onDashArrayChange={d => { setDashArray(d); dashArrayRef.current = d; }}
          />
        </div>
      </div>

      {/* Right panel toggle buttons */}
      <div style={{
        position: 'absolute',
        top: 60,
        right: showLayers || showPlanning ? 240 : 12,
        display: 'flex',
        flexDirection: 'column',
        gap: 6,
        zIndex: 150,
        transition: 'right 200ms ease',
      }}>
        <button
          className={`btn-icon tooltip panel ${showLayers ? 'active' : ''}`}
          data-tip="Layers"
          onClick={() => { setShowLayers(s => !s); setShowPlanning(false); }}
          style={{ width: 36, height: 36 }}
        >
          <Layers size={16} />
        </button>
        <button
          className={`btn-icon tooltip panel ${showPlanning ? 'active' : ''}`}
          data-tip="Planning"
          onClick={() => { setShowPlanning(s => !s); setShowLayers(false); }}
          style={{ width: 36, height: 36 }}
        >
          <Layout size={16} />
        </button>
        <button
          className="btn-icon tooltip panel"
          data-tip="Search"
          onClick={() => setShowSearch(s => !s)}
          style={{ width: 36, height: 36 }}
        >
          <Search size={16} />
        </button>
      </div>

      {/* Layers panel */}
      {showLayers && (
        <LayersPanel
          layers={session.layers}
          activeLayerId={session.activeLayerId}
          onLayersChange={layers => updateSession({ layers })}
          onActiveLayerChange={id => updateSession({ activeLayerId: id })}
          onClose={() => setShowLayers(false)}
        />
      )}

      {/* Planning panel */}
      {showPlanning && (
        <PlanningPanel
          objects={objects}
          onAddObject={addObject}
          onUpdateObject={updateObjectById}
          onDeleteObject={deleteObject}
          onClose={() => setShowPlanning(false)}
          activeLayerId={session.activeLayerId}
        />
      )}

      {/* Search panel */}
      {showSearch && (
        <div className="panel animate-slide-right" style={{
          position: 'absolute',
          top: 60,
          right: 12,
          width: 260,
          zIndex: 200,
          padding: 12,
        }}>
          <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
            <input
              autoFocus
              placeholder="Search objects…"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              style={{
                flex: 1,
                padding: '6px 10px',
                borderRadius: 7,
                border: '1px solid var(--color-border)',
                background: 'var(--color-bg)',
                color: 'var(--color-text)',
                fontFamily: 'inherit',
                fontSize: 13,
                outline: 'none',
              }}
            />
            <button className="btn-icon" onClick={() => setShowSearch(false)}><X size={14} /></button>
          </div>
          {searchQuery && (
            <div>
              {searchResults.length === 0 && (
                <div style={{ fontSize: 12, color: 'var(--color-muted)', textAlign: 'center', padding: '12px 0' }}>
                  No results found
                </div>
              )}
              {searchResults.map(obj => (
                <button
                  key={obj.id}
                  onClick={() => focusObject(obj)}
                  style={{
                    width: '100%',
                    textAlign: 'left',
                    background: 'none',
                    border: 'none',
                    padding: '7px 8px',
                    borderRadius: 6,
                    cursor: 'pointer',
                    fontFamily: 'inherit',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 8,
                  }}
                  onMouseEnter={e => (e.currentTarget.style.background = 'var(--color-border)')}
                  onMouseLeave={e => (e.currentTarget.style.background = 'none')}
                >
                  <StickyNote size={13} style={{ color: 'var(--color-muted)' }} />
                  <span style={{ fontSize: 12, color: 'var(--color-text)', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {obj.text || obj.title || '(untitled)'}
                  </span>
                  <ChevronRight size={12} style={{ color: 'var(--color-muted)' }} />
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Text editing overlay */}
      {textEditingId && (() => {
        const obj = objects.find(o => o.id === textEditingId);
        if (!obj) return null;
        const { offsetX, offsetY, zoom } = view;
        const sx = obj.x * zoom + offsetX;
        const sy = obj.y * zoom + offsetY;
        const sw = (obj.width || 300) * zoom;
        const sh = (obj.height || 120) * zoom;
        return (
          <div style={{
            position: 'absolute',
            top: 52 + sy,
            left: sx,
            width: sw,
            minHeight: sh,
            zIndex: 500,
          }}>
            <textarea
              autoFocus
              value={textEditValue}
              onChange={e => setTextEditValue(e.target.value)}
              onBlur={() => {
                updateObjectById(textEditingId, { text: textEditValue });
                setTextEditingId(null);
              }}
              onKeyDown={e => {
                if (e.key === 'Escape') {
                  updateObjectById(textEditingId, { text: textEditValue });
                  setTextEditingId(null);
                }
                e.stopPropagation();
              }}
              style={{
                width: '100%',
                minHeight: sh,
                background: obj.type === 'sticky' ? (obj.noteColor || '#fef3c7') : 'transparent',
                border: '2px solid #4f6ef7',
                borderRadius: obj.type === 'sticky' ? 6 : 3,
                padding: obj.type === 'sticky' ? '32px 10px 10px' : '2px 4px',
                fontFamily: obj.fontFamily || 'Inter, sans-serif',
                fontSize: (obj.fontSize || 14) * zoom,
                color: obj.type === 'text' ? (obj.color || '#1a1d23') : '#374151',
                resize: 'both',
                outline: 'none',
                boxSizing: 'border-box',
                lineHeight: 1.5,
              }}
              placeholder={obj.type === 'sticky' ? 'Write a note…' : 'Type here…'}
            />
          </div>
        );
      })()}

      {/* Context menu */}
      {contextMenu && (
        <>
          <div className="context-menu" style={{ left: contextMenu.x, top: contextMenu.y }}>
            {contextMenu.objectId ? (
              <>
                <div className="context-menu-item" onClick={() => {
                  setSelectedIds(new Set([contextMenu.objectId!]));
                  setContextMenu(null);
                }}>
                  Select
                </div>
                <div className="context-menu-item" onClick={() => {
                  const obj = objects.find(o => o.id === contextMenu.objectId);
                  if (obj) { copySelected(); }
                  setContextMenu(null);
                }}>
                  Copy
                </div>
                <div className="context-menu-item" onClick={() => {
                  setSelectedIds(new Set([contextMenu.objectId!]));
                  selectedIdsRef.current = new Set([contextMenu.objectId!]);
                  duplicateSelected();
                  setContextMenu(null);
                }}>
                  Duplicate
                </div>
                <div className="context-menu-separator" />
                {(() => {
                  const obj = objects.find(o => o.id === contextMenu.objectId);
                  if (!obj) return null;
                  return (
                    <>
                      <div className="context-menu-item" onClick={() => {
                        updateObjectById(obj.id, { locked: !obj.locked });
                        setContextMenu(null);
                      }}>
                        {obj.locked ? 'Unlock' : 'Lock'}
                      </div>
                      <div className="context-menu-item" onClick={() => {
                        updateObjectById(obj.id, { visible: !obj.visible });
                        setContextMenu(null);
                      }}>
                        {obj.visible === false ? 'Show' : 'Hide'}
                      </div>
                    </>
                  );
                })()}
                <div className="context-menu-separator" />
                <div className="context-menu-item danger" onClick={() => {
                  deleteObject(contextMenu.objectId!);
                  setContextMenu(null);
                }}>
                  <span>Delete</span>
                </div>
              </>
            ) : (
              <>
                <div className="context-menu-item" onClick={() => { pasteObjects(); setContextMenu(null); }}>
                  Paste
                </div>
                <div className="context-menu-item" onClick={() => {
                  setSelectedIds(new Set(objects.map(o => o.id)));
                  setContextMenu(null);
                }}>
                  Select All
                </div>
                <div className="context-menu-separator" />
                <div className="context-menu-item" onClick={() => { handleGridModeChange(session.settings.gridMode === 'none' ? 'dots' : 'none'); setContextMenu(null); }}>
                  {session.settings.gridMode === 'none' ? 'Show Grid' : 'Hide Grid'}
                </div>
                <div className="context-menu-item" onClick={() => { const nv = { offsetX: 0, offsetY: 0, zoom: 1 }; viewRef.current = nv; setView(nv); scheduleRender(); setContextMenu(null); }}>
                  Reset View
                </div>
              </>
            )}
          </div>
          <div style={{ position: 'fixed', inset: 0, zIndex: 9980 }} onClick={() => setContextMenu(null)} />
        </>
      )}

      {/* Command palette */}
      {showCommandPalette && (
        <CommandPalette
          commands={commands}
          onClose={() => setShowCommandPalette(false)}
        />
      )}

      {/* Floating quick-add button */}
      <div style={{
        position: 'absolute',
        bottom: 40,
        left: '50%',
        transform: 'translateX(-50%)',
        display: 'flex',
        gap: 8,
        zIndex: 150,
      }}>
        {[
          { tool: 'sticky' as ToolType, icon: <StickyNote size={14} />, label: 'Note', color: '#f59e0b' },
          { tool: 'text' as ToolType, icon: <span style={{ fontSize: 13, fontWeight: 700 }}>T</span>, label: 'Text', color: '#4f6ef7' },
          { tool: 'rect' as ToolType, icon: <span style={{ fontSize: 11 }}>□</span>, label: 'Shape', color: '#10b981' },
        ].map(item => (
          <button
            key={item.tool}
            onClick={() => { setActiveTool(item.tool); activeToolRef.current = item.tool; }}
            style={{
              height: 32,
              padding: '0 14px',
              borderRadius: 100,
              borderWidth: 1,
              borderStyle: 'solid',
              borderColor: activeTool === item.tool ? item.color : 'var(--color-border)',
              background: activeTool === item.tool ? item.color : 'var(--color-surface)',
              color: activeTool === item.tool ? '#fff' : 'var(--color-text)',
              fontFamily: 'inherit',
              fontSize: 12,
              fontWeight: 500,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              boxShadow: 'var(--shadow-md)',
              transition: 'background 150ms, color 150ms',
            }}
          >
            {item.icon} {item.label}
          </button>
        ))}
      </div>

      {/* Status bar */}
      <div className="status-bar">
        <span>
          {activeTool.charAt(0).toUpperCase() + activeTool.slice(1)} tool
        </span>
        <span>·</span>
        <span>{objects.length} objects</span>
        <span>·</span>
        <span>{selectedIds.size > 0 ? `${selectedIds.size} selected` : 'None selected'}</span>
        <span>·</span>
        <span>Layer: {session.layers.find(l => l.id === session.activeLayerId)?.name || '—'}</span>
        <span style={{ marginLeft: 'auto' }}>
          Zoom {Math.round(view.zoom * 100)}%
        </span>
        <span>·</span>
        <span>
          {objects.length > 0 ? `${history.length} history steps` : 'Empty canvas'}
        </span>
      </div>

      {/* Zoom controls */}
      <div style={{
        position: 'absolute',
        bottom: 36,
        right: 180,
        display: 'flex',
        gap: 4,
        zIndex: 150,
      }}>
        <button
          className="btn-icon panel"
          onClick={() => zoomAtPoint(canvasSize.w / 2, canvasSize.h / 2, 0.2)}
          style={{ width: 30, height: 30 }}
          title="Zoom in"
        >
          <ZoomIn size={14} />
        </button>
        <button
          className="btn-icon panel"
          onClick={() => { const nv = { offsetX: 0, offsetY: 0, zoom: 1 }; viewRef.current = nv; setView(nv); scheduleRender(); }}
          style={{ width: 30, height: 30 }}
          title="Reset zoom"
        >
          <RotateCcw size={14} />
        </button>
        <button
          className="btn-icon panel"
          onClick={() => zoomAtPoint(canvasSize.w / 2, canvasSize.h / 2, -0.2)}
          style={{ width: 30, height: 30 }}
          title="Zoom out"
        >
          <ZoomOut size={14} />
        </button>
      </div>

      {/* Quick add FAB */}
      <button
        onClick={() => { setActiveTool('sticky'); activeToolRef.current = 'sticky'; }}
        style={{
          position: 'absolute',
          bottom: 60,
          right: 12,
          width: 44,
          height: 44,
          borderRadius: '50%',
          border: 'none',
          background: 'linear-gradient(135deg, #4f6ef7, #7c5cfa)',
          color: '#fff',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 4px 16px rgba(79,110,247,0.4)',
          zIndex: 150,
          transition: 'transform 150ms',
        }}
        onMouseEnter={e => (e.currentTarget.style.transform = 'scale(1.08)')}
        onMouseLeave={e => (e.currentTarget.style.transform = 'scale(1)')}
        title="Quick add sticky note"
      >
        <Plus size={20} />
      </button>
    </div>
  );
}

function pointInPolygon(x: number, y: number, pts: number[]): boolean {
  let inside = false;
  const n = pts.length / 2;
  for (let i = 0, j = n - 1; i < n; j = i++) {
    const xi = pts[i * 2], yi = pts[i * 2 + 1];
    const xj = pts[j * 2], yj = pts[j * 2 + 1];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) {
      inside = !inside;
    }
  }
  return inside;
}
