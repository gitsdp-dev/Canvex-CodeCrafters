import { useState } from 'react';
import {
  X, Plus, CheckSquare, Square as SquareIcon, Trash2, Pin,
  GitBranch, Layout, Calendar, Clock, ListChecks,
  ChevronDown, ChevronRight,
} from 'lucide-react';
import { BoardObject, generateId } from '../utils/storage';

interface PlanningPanelProps {
  objects: BoardObject[];
  onAddObject: (obj: BoardObject) => void;
  onUpdateObject: (id: string, updates: Partial<BoardObject>) => void;
  onDeleteObject: (id: string) => void;
  onClose: () => void;
  activeLayerId: string;
}

const KANBAN_COLS = ['To Do', 'In Progress', 'Done'];
const PRIORITIES = ['low', 'medium', 'high'];
const PRIORITY_COLORS: Record<string, string> = {
  low: '#10b981',
  medium: '#f59e0b',
  high: '#ef4444',
};

const TEMPLATES = [
  { id: 'daily', label: 'Daily Planner', icon: <Calendar size={14} />, desc: 'Plan your day' },
  { id: 'weekly', label: 'Weekly Planner', icon: <Calendar size={14} />, desc: 'Plan your week' },
  { id: 'kanban', label: 'Kanban Board', icon: <Layout size={14} />, desc: 'Track tasks' },
  { id: 'mindmap', label: 'Mind Map', icon: <GitBranch size={14} />, desc: 'Brainstorm ideas' },
  { id: 'timeline', label: 'Timeline', icon: <Clock size={14} />, desc: 'Plan milestones' },
  { id: 'checklist', label: 'Checklist', icon: <ListChecks size={14} />, desc: 'Track items' },
];

export default function PlanningPanel({
  objects,
  onAddObject,
  onUpdateObject,
  onDeleteObject,
  onClose,
  activeLayerId,
}: PlanningPanelProps) {
  const [activeTab, setActiveTab] = useState<'tasks' | 'templates' | 'notes'>('tasks');
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskStatus, setNewTaskStatus] = useState('To Do');
  const [newTaskPriority, setNewTaskPriority] = useState<string>('medium');
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    'To Do': true,
    'In Progress': true,
    'Done': false,
  });

  const taskObjects = objects.filter(o => o.type === 'sticky' && o.status !== undefined);
  const noteObjects = objects.filter(o => o.type === 'sticky' && o.status === undefined);

  const addTask = () => {
    if (!newTaskTitle.trim()) return;
    const obj: BoardObject = {
      id: generateId(),
      type: 'sticky',
      x: 100 + Math.random() * 400,
      y: 100 + Math.random() * 300,
      width: 180,
      height: 100,
      layerId: activeLayerId,
      visible: true,
      locked: false,
      opacity: 1,
      text: newTaskTitle,
      noteColor: newTaskStatus === 'Done' ? '#d1fae5' : newTaskStatus === 'In Progress' ? '#dbeafe' : '#fef3c7',
      status: newTaskStatus,
      priority: newTaskPriority,
      pinned: false,
    };
    onAddObject(obj);
    setNewTaskTitle('');
  };

  const toggleTaskStatus = (obj: BoardObject) => {
    const statuses = KANBAN_COLS;
    const idx = statuses.indexOf(obj.status || 'To Do');
    const nextStatus = statuses[(idx + 1) % statuses.length];
    const noteColor = nextStatus === 'Done' ? '#d1fae5' : nextStatus === 'In Progress' ? '#dbeafe' : '#fef3c7';
    onUpdateObject(obj.id, { status: nextStatus, noteColor });
  };

  const togglePin = (obj: BoardObject) => {
    onUpdateObject(obj.id, { pinned: !obj.pinned });
  };

  const addTemplate = (templateId: string) => {
    const cx = 200 + Math.random() * 200;
    const cy = 150 + Math.random() * 150;

    if (templateId === 'kanban') {
      KANBAN_COLS.forEach((col, ci) => {
        const headerObj: BoardObject = {
          id: generateId(),
          type: 'sticky',
          x: cx + ci * 210,
          y: cy,
          width: 190,
          height: 36,
          layerId: activeLayerId,
          visible: true,
          locked: false,
          opacity: 1,
          text: col,
          noteColor: col === 'Done' ? '#d1fae5' : col === 'In Progress' ? '#dbeafe' : '#fef3c7',
          status: col,
          fontSize: 14,
        };
        onAddObject(headerObj);
      });
    } else if (templateId === 'checklist') {
      const items = ['Item 1', 'Item 2', 'Item 3', 'Item 4'];
      items.forEach((item, i) => {
        const obj: BoardObject = {
          id: generateId(),
          type: 'sticky',
          x: cx,
          y: cy + i * 64,
          width: 220,
          height: 52,
          layerId: activeLayerId,
          visible: true,
          locked: false,
          opacity: 1,
          text: `☐ ${item}`,
          noteColor: '#f8f9fb',
          checked: false,
        };
        onAddObject(obj);
      });
    } else if (templateId === 'daily') {
      const hours = ['9:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', '1:00 PM', '2:00 PM'];
      hours.forEach((h, i) => {
        const obj: BoardObject = {
          id: generateId(),
          type: 'sticky',
          x: cx,
          y: cy + i * 56,
          width: 240,
          height: 48,
          layerId: activeLayerId,
          visible: true,
          locked: false,
          opacity: 1,
          text: `${h} — `,
          noteColor: i % 2 === 0 ? '#f8f9fb' : '#fafafa',
        };
        onAddObject(obj);
      });
    } else if (templateId === 'mindmap') {
      // Central node
      const center: BoardObject = {
        id: generateId(),
        type: 'shape',
        shapeType: 'ellipse',
        x: cx,
        y: cy,
        width: 140,
        height: 60,
        layerId: activeLayerId,
        visible: true,
        locked: false,
        opacity: 1,
        color: '#4f6ef7',
        strokeWidth: 2,
        filled: true,
        fillColor: '#dbeafe',
        text: 'Main Idea',
      };
      onAddObject(center);

      const branches = ['Branch A', 'Branch B', 'Branch C', 'Branch D'];
      const angles = [-60, -20, 20, 60];
      branches.forEach((branch, bi) => {
        const bx = cx + 200 * Math.cos((angles[bi] * Math.PI) / 180);
        const by = cy + 30 + 150 * Math.sin((angles[bi] * Math.PI) / 180);
        const branchObj: BoardObject = {
          id: generateId(),
          type: 'shape',
          shapeType: 'rect',
          x: bx,
          y: by,
          width: 110,
          height: 40,
          layerId: activeLayerId,
          visible: true,
          locked: false,
          opacity: 1,
          color: '#7c5cfa',
          strokeWidth: 1.5,
          filled: true,
          fillColor: '#ede9fe',
          text: branch,
        };
        onAddObject(branchObj);
        // Connector
        const connector: BoardObject = {
          id: generateId(),
          type: 'arrow',
          x: cx + 140,
          y: cy + 30,
          x2: bx,
          y2: by + 20,
          layerId: activeLayerId,
          visible: true,
          locked: false,
          opacity: 1,
          color: '#9ca3af',
          strokeWidth: 1.5,
          endArrow: false,
        };
        onAddObject(connector);
      });
    } else if (templateId === 'timeline') {
      const milestones = ['Start', 'Phase 1', 'Phase 2', 'Phase 3', 'End'];
      milestones.forEach((m, i) => {
        const obj: BoardObject = {
          id: generateId(),
          type: 'sticky',
          x: cx + i * 160,
          y: cy,
          width: 130,
          height: 70,
          layerId: activeLayerId,
          visible: true,
          locked: false,
          opacity: 1,
          text: m,
          noteColor: i === 0 || i === milestones.length - 1 ? '#dbeafe' : '#fef3c7',
        };
        onAddObject(obj);
        if (i < milestones.length - 1) {
          const arrow: BoardObject = {
            id: generateId(),
            type: 'arrow',
            x: cx + i * 160 + 130,
            y: cy + 35,
            x2: cx + (i + 1) * 160,
            y2: cy + 35,
            layerId: activeLayerId,
            visible: true,
            locked: false,
            opacity: 1,
            color: '#6b7280',
            strokeWidth: 2,
          };
          onAddObject(arrow);
        }
      });
    } else if (templateId === 'weekly') {
      const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      days.forEach((day, di) => {
        const header: BoardObject = {
          id: generateId(),
          type: 'sticky',
          x: cx + di * 100,
          y: cy,
          width: 90,
          height: 36,
          layerId: activeLayerId,
          visible: true,
          locked: false,
          opacity: 1,
          text: day,
          noteColor: di >= 5 ? '#fce7f3' : '#dbeafe',
          fontSize: 13,
        };
        onAddObject(header);
        for (let ri = 0; ri < 3; ri++) {
          const slot: BoardObject = {
            id: generateId(),
            type: 'sticky',
            x: cx + di * 100,
            y: cy + 44 + ri * 54,
            width: 90,
            height: 46,
            layerId: activeLayerId,
            visible: true,
            locked: false,
            opacity: 1,
            text: '',
            noteColor: '#f8f9fb',
          };
          onAddObject(slot);
        }
      });
    }
  };

  const tasksByStatus = KANBAN_COLS.reduce((acc, col) => {
    acc[col] = taskObjects.filter(o => o.status === col);
    return acc;
  }, {} as Record<string, BoardObject[]>);

  const toggleSection = (col: string) => {
    setExpandedSections(s => ({ ...s, [col]: !s[col] }));
  };

  return (
    <div className="panel animate-slide-right" style={{
      position: 'absolute',
      right: 12,
      top: 60,
      width: 260,
      zIndex: 200,
      maxHeight: 'calc(100vh - 120px)',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '10px 12px 8px',
        borderBottom: '1px solid var(--color-border)',
        flexShrink: 0,
      }}>
        <span style={{ fontWeight: 700, fontSize: 13 }}>Planning</span>
        <button className="btn-icon" onClick={onClose} style={{ width: 26, height: 26 }}>
          <X size={13} />
        </button>
      </div>

      {/* Tabs */}
      <div style={{
        display: 'flex',
        borderBottom: '1px solid var(--color-border)',
        flexShrink: 0,
      }}>
        {(['tasks', 'templates', 'notes'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            style={{
              flex: 1,
              padding: '7px 4px',
              border: 'none',
              background: 'none',
              fontSize: 12,
              fontWeight: activeTab === tab ? 700 : 400,
              color: activeTab === tab ? '#4f6ef7' : 'var(--color-muted)',
              cursor: 'pointer',
              borderBottom: `2px solid ${activeTab === tab ? '#4f6ef7' : 'transparent'}`,
              fontFamily: 'inherit',
              textTransform: 'capitalize',
              transition: 'color 150ms',
            }}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '8px' }}>
        {activeTab === 'tasks' && (
          <div>
            {/* Add task */}
            <div style={{ marginBottom: 10 }}>
              <input
                placeholder="New task…"
                value={newTaskTitle}
                onChange={e => setNewTaskTitle(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') addTask(); }}
                style={{
                  width: '100%',
                  padding: '6px 10px',
                  borderRadius: 7,
                  border: '1px solid var(--color-border)',
                  background: 'var(--color-bg)',
                  color: 'var(--color-text)',
                  fontFamily: 'inherit',
                  fontSize: 13,
                  outline: 'none',
                  marginBottom: 6,
                }}
              />
              <div style={{ display: 'flex', gap: 6 }}>
                <select
                  value={newTaskStatus}
                  onChange={e => setNewTaskStatus(e.target.value)}
                  style={{
                    flex: 1,
                    padding: '4px 6px',
                    borderRadius: 5,
                    border: '1px solid var(--color-border)',
                    background: 'var(--color-bg)',
                    color: 'var(--color-text)',
                    fontFamily: 'inherit',
                    fontSize: 11,
                  }}
                >
                  {KANBAN_COLS.map(c => <option key={c}>{c}</option>)}
                </select>
                <select
                  value={newTaskPriority}
                  onChange={e => setNewTaskPriority(e.target.value)}
                  style={{
                    flex: 1,
                    padding: '4px 6px',
                    borderRadius: 5,
                    border: '1px solid var(--color-border)',
                    background: 'var(--color-bg)',
                    color: 'var(--color-text)',
                    fontFamily: 'inherit',
                    fontSize: 11,
                  }}
                >
                  {PRIORITIES.map(p => <option key={p}>{p}</option>)}
                </select>
                <button
                  onClick={addTask}
                  style={{
                    padding: '4px 10px',
                    borderRadius: 5,
                    border: 'none',
                    background: '#4f6ef7',
                    color: '#fff',
                    fontFamily: 'inherit',
                    fontSize: 12,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 3,
                  }}
                >
                  <Plus size={12} />
                </button>
              </div>
            </div>

            {/* Pinned tasks */}
            {taskObjects.filter(o => o.pinned).length > 0 && (
              <div style={{ marginBottom: 8 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: '#f59e0b', marginBottom: 4, display: 'flex', alignItems: 'center', gap: 4 }}>
                  <Pin size={11} /> PINNED
                </div>
                {taskObjects.filter(o => o.pinned).map(task => (
                  <TaskItem key={task.id} task={task} onDelete={onDeleteObject} onToggle={toggleTaskStatus} onPin={togglePin} />
                ))}
              </div>
            )}

            {/* Tasks by status */}
            {KANBAN_COLS.map(col => (
              <div key={col} style={{ marginBottom: 6 }}>
                <button
                  onClick={() => toggleSection(col)}
                  style={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    background: 'none',
                    border: 'none',
                    padding: '4px 2px',
                    cursor: 'pointer',
                    fontFamily: 'inherit',
                    color: 'var(--color-text)',
                  }}
                >
                  {expandedSections[col] ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
                  <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--color-muted)' }}>
                    {col.toUpperCase()}
                  </span>
                  <span style={{
                    marginLeft: 'auto',
                    fontSize: 10,
                    background: 'var(--color-border)',
                    borderRadius: 10,
                    padding: '1px 6px',
                    color: 'var(--color-muted)',
                  }}>
                    {tasksByStatus[col].length}
                  </span>
                </button>
                {expandedSections[col] && tasksByStatus[col].map(task => (
                  <TaskItem key={task.id} task={task} onDelete={onDeleteObject} onToggle={toggleTaskStatus} onPin={togglePin} />
                ))}
              </div>
            ))}
          </div>
        )}

        {activeTab === 'templates' && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
            {TEMPLATES.map(t => (
              <button
                key={t.id}
                onClick={() => addTemplate(t.id)}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'flex-start',
                  gap: 4,
                  padding: '10px',
                  borderRadius: 8,
                  border: '1px solid var(--color-border)',
                  background: 'var(--color-bg)',
                  cursor: 'pointer',
                  fontFamily: 'inherit',
                  textAlign: 'left',
                  transition: 'background 150ms, box-shadow 150ms',
                  color: 'var(--color-text)',
                }}
                onMouseEnter={e => {
                  e.currentTarget.style.background = 'var(--color-surface)';
                  e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.background = 'var(--color-bg)';
                  e.currentTarget.style.boxShadow = 'none';
                }}
              >
                <div style={{ color: '#4f6ef7' }}>{t.icon}</div>
                <span style={{ fontSize: 12, fontWeight: 600 }}>{t.label}</span>
                <span style={{ fontSize: 11, color: 'var(--color-muted)' }}>{t.desc}</span>
              </button>
            ))}
          </div>
        )}

        {activeTab === 'notes' && (
          <div>
            {noteObjects.length === 0 && (
              <div style={{ textAlign: 'center', padding: '24px 12px', color: 'var(--color-muted)', fontSize: 12 }}>
                <SquareIcon size={28} style={{ opacity: 0.3, marginBottom: 8 }} />
                <p style={{ margin: 0 }}>No sticky notes yet.<br />Use the sticky tool on the canvas.</p>
              </div>
            )}
            {noteObjects.map(note => (
              <div key={note.id} style={{
                background: note.noteColor || '#fef3c7',
                borderRadius: 6,
                padding: '8px 10px',
                marginBottom: 6,
                fontSize: 12,
                position: 'relative',
              }}>
                <p style={{ margin: 0, lineHeight: 1.4, color: '#374151' }}>{note.text || '(empty)'}</p>
                <button
                  onClick={() => onDeleteObject(note.id)}
                  style={{
                    position: 'absolute',
                    top: 4,
                    right: 4,
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    color: '#9ca3af',
                    padding: 2,
                  }}
                >
                  <X size={11} />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function TaskItem({
  task,
  onDelete,
  onToggle,
  onPin,
}: {
  task: BoardObject;
  onDelete: (id: string) => void;
  onToggle: (obj: BoardObject) => void;
  onPin: (obj: BoardObject) => void;
}) {
  const isDone = task.status === 'Done';
  return (
    <div style={{
      display: 'flex',
      alignItems: 'flex-start',
      gap: 6,
      padding: '5px 4px',
      borderRadius: 6,
      marginBottom: 2,
      background: 'var(--color-bg)',
      transition: 'background 100ms',
    }}
      onMouseEnter={e => (e.currentTarget.style.background = 'var(--color-border)')}
      onMouseLeave={e => (e.currentTarget.style.background = 'var(--color-bg)')}
    >
      <button
        onClick={() => onToggle(task)}
        style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, marginTop: 2, color: isDone ? '#10b981' : 'var(--color-muted)' }}
      >
        {isDone ? <CheckSquare size={14} /> : <SquareIcon size={14} />}
      </button>
      <span style={{
        flex: 1,
        fontSize: 12,
        lineHeight: 1.4,
        textDecoration: isDone ? 'line-through' : 'none',
        opacity: isDone ? 0.6 : 1,
        color: 'var(--color-text)',
      }}>
        {task.text}
      </span>
      <div style={{
        width: 6,
        height: 6,
        borderRadius: '50%',
        background: PRIORITY_COLORS[task.priority || 'medium'],
        marginTop: 5,
        flexShrink: 0,
      }} />
      <button
        onClick={() => onPin(task)}
        style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, color: task.pinned ? '#f59e0b' : 'var(--color-muted)' }}
      >
        <Pin size={11} />
      </button>
      <button
        onClick={() => onDelete(task.id)}
        style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, color: '#ef4444' }}
      >
        <Trash2 size={11} />
      </button>
    </div>
  );
}
