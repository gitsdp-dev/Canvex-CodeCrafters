import { useState, useEffect, useCallback } from 'react';
import HomePage from './components/HomePage';
import WhiteboardWorkspace from './components/WhiteboardWorkspace';
import { BoardSession, getAppSettings, loadSession, saveAppSettings, createNewSession } from './utils/storage';

export type AppView = 'home' | 'workspace';

export interface AppState {
  view: AppView;
  currentSession: BoardSession | null;
  darkMode: boolean;
}

export default function App() {
  const [appState, setAppState] = useState<AppState>({
    view: 'home',
    currentSession: null,
    darkMode: false,
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const settings = await getAppSettings();
        const dark = settings.darkMode ?? false;
        if (dark) document.documentElement.classList.add('dark');
        setAppState(prev => ({ ...prev, darkMode: dark }));
      } catch {}
      setIsLoading(false);
    })();
  }, []);

  const handleOpenWorkspace = useCallback(async (session?: BoardSession) => {
    let targetSession = session;
    if (!targetSession) {
      // Load last session or create new
      const settings = await getAppSettings();
      if (settings.lastSessionId) {
        const loaded = await loadSession(settings.lastSessionId);
        targetSession = loaded || createNewSession();
      } else {
        targetSession = createNewSession();
      }
    }
    setAppState(prev => ({ ...prev, view: 'workspace', currentSession: targetSession! }));
  }, []);

  const handleNewBoard = useCallback(() => {
    const newSession = createNewSession();
    setAppState(prev => ({ ...prev, view: 'workspace', currentSession: newSession }));
  }, []);

  const handleReturnHome = useCallback((updatedSession: BoardSession) => {
    setAppState(prev => ({
      ...prev,
      view: 'home',
      currentSession: updatedSession,
    }));
  }, []);

  const handleToggleDark = useCallback(async (dark: boolean) => {
    if (dark) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
    setAppState(prev => ({ ...prev, darkMode: dark }));
    const settings = await getAppSettings();
    await saveAppSettings({ ...settings, darkMode: dark });
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen w-screen"
        style={{ background: 'var(--color-bg)' }}>
        <div className="flex flex-col items-center gap-3">
          <div className="flex gap-1.5">
            {[0,1,2].map(i => (
              <div key={i} className="w-2 h-2 rounded-full animate-pulse-dot"
                style={{ background: 'var(--color-accent)', animationDelay: `${i * 200}ms` }} />
            ))}
          </div>
          <span style={{ color: 'var(--color-muted)', fontSize: 13 }}>Loading Canvex…</span>
        </div>
      </div>
    );
  }

  if (appState.view === 'workspace' && appState.currentSession) {
    return (
      <WhiteboardWorkspace
        session={appState.currentSession}
        darkMode={appState.darkMode}
        onReturnHome={handleReturnHome}
        onToggleDark={handleToggleDark}
      />
    );
  }

  return (
    <HomePage
      lastSession={appState.currentSession}
      darkMode={appState.darkMode}
      onOpenWorkspace={handleOpenWorkspace}
      onNewBoard={handleNewBoard}
      onToggleDark={handleToggleDark}
    />
  );
}
